import React, { useEffect, useState, useCallback, useRef } from 'react';
import './App.css';
import ConsumerQRLookup from './components/ConsumerQRLookup';
import ProductSearchBar from './components/ProductSearchBar';

const API        = 'http://localhost:5001/api/products';
const UPLOAD_API = 'http://localhost:5001/api/upload';
const USDA_NUMBER = '1-800-495-7222';

const accounts = {
  farmer:     ['Farmer',               'farmer.demo',     'Farmer@123'],
  usda:       ['USDA Reviewer (demo)', 'usda.demo',       'USDA@123'],
  aggregator: ['Aggregator',           'aggregator.demo', 'Aggregator@123'],
  retailer:   ['Retailer',             'retailer.demo',   'Retailer@123'],
  consumer:   ['Consumer',             'consumer.demo',   'Consumer@123'],
};

const emptyForm = {
  name: '', farm: '', location: '',
  farmerPrice: '', retailPrice: '',
  category: 'plant', emoji: '',
  productImage: '',
};

const STATUS_COLORS = {
  draft: '#f59e0b',
  'awaiting-usda': '#3b82f6',
  'usda-approved': '#10b981',
  'usda-correction-required': '#ef4444',
  'in-transit': '#8b5cf6',
  'fully-verified': '#059669',
};

/* ── Farmer Product Image Upload component ── */
function ProductImageUpload({ imageUrl, onUploaded }) {
  const galleryRef = useRef(null);
  const cameraRef  = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [uploadErr, setUploadErr] = useState('');

  const handleFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadErr('');
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('image', file);
      const res  = await fetch(UPLOAD_API, { method: 'POST', body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Upload failed.');
      onUploaded(data.imageUrl);
    } catch (err) {
      setUploadErr(err.message);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  return (
    <div className="prod-img-upload">
      <p className="prod-img-label">PRODUCT PHOTO</p>

      {/* Preview */}
      {imageUrl ? (
        <div className="prod-img-preview-wrap">
          <img src={imageUrl} alt="Product" className="prod-img-preview" />
          <button
            type="button"
            className="prod-img-remove"
            onClick={() => onUploaded('')}
            title="Remove photo"
          >✕ Remove</button>
        </div>
      ) : (
        <div className="prod-img-placeholder">
          <span>🖼️</span>
          <small>No photo uploaded yet</small>
        </div>
      )}

      {/* Upload buttons */}
      <div className="prod-img-btns">
        {/* Gallery / file picker */}
        <label className="prod-img-btn" title="Choose from files">
          <input
            ref={galleryRef}
            type="file"
            accept="image/*"
            onChange={handleFile}
            style={{ display: 'none' }}
          />
          {uploading ? '⏳ Uploading…' : '📁 Upload Photo'}
        </label>

        {/* Camera capture */}
        <label className="prod-img-btn prod-img-btn-camera" title="Take a photo with camera">
          <input
            ref={cameraRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleFile}
            style={{ display: 'none' }}
          />
          📷 Take Photo
        </label>
      </div>

      {uploadErr && <small className="prod-img-err">⚠️ {uploadErr}</small>}
      <small className="prod-img-hint">
        Saved to <code>server/uploads/products/</code> — PNG, JPG, WEBP (max 10 MB)
      </small>
    </div>
  );
}

export default function App() {
  const [role, setRole]           = useState('farmer');
  const [u, setU]                 = useState('farmer.demo');
  const [pw, setPw]               = useState('Farmer@123');
  const [inApp, setInApp]         = useState(false);
  const [items, setItems]         = useState([]);
  const [displayed, setDisplayed] = useState([]);
  const [msg, setMsg]             = useState('');
  const [msgType, setMsgType]     = useState('info');
  const [form, setForm]           = useState(emptyForm);
  const [editing, setEditing]     = useState(null);
  const [warnings, setWarnings]   = useState([]);

  // USDA QR evidence upload state
  const [usdaQrFile, setUsdaQrFile] = useState('');

  const headers = () => ({ 'Content-Type': 'application/json', 'x-user-role': role });

  const load = useCallback(() => {
    fetch(API, { headers: headers() })
      .then(r => r.json())
      .then(data => { setItems(data); setDisplayed(data); })
      .catch(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role]);

  useEffect(() => { if (inApp) load(); }, [inApp, load]);

  const choose = x => { setRole(x); setU(accounts[x][1]); setPw(accounts[x][2]); setEditing(null); setWarnings([]); };
  const login = e => {
    e.preventDefault();
    const a = accounts[role];
    if (u !== a[1] || pw !== a[2]) return notify('Use the pre-filled demo credentials.', 'error');
    setInApp(true);
    setMsg('');
  };

  const notify = (text, type = 'info') => { setMsg(text); setMsgType(type); };

  const call = (path, body) =>
    fetch(API + path, { method: 'POST', headers: headers(), body: JSON.stringify(body || {}) })
      .then(async r => {
        const d = await r.json();
        if (!r.ok) throw Error(d.message);
        if (d.dataWarnings && d.dataWarnings.length > 0) {
          setWarnings(d.dataWarnings);
          notify('Ledger updated — but data warnings were detected. Please review.', 'warning');
        } else {
          notify(d.message || 'Ledger updated securely.', 'info');
        }
        load();
      })
      .catch(e => notify(e.message, 'error'));

  const add = e => {
    e.preventDefault();
    fetch(API, { method: 'POST', headers: headers(), body: JSON.stringify(form) })
      .then(async r => {
        const d = await r.json();
        if (!r.ok) throw Error(d.message);
        if (d.dataWarnings && d.dataWarnings.length > 0) {
          setWarnings(d.dataWarnings);
          notify('Draft created — but data warnings were detected. Please review the alert below.', 'warning');
        } else {
          setWarnings([]);
          notify('Draft harvest record created successfully.', 'info');
        }
        setForm(emptyForm);
        load();
      })
      .catch(e => notify(e.message, 'error'));
  };

  const edit = e => {
    e.preventDefault();
    fetch(API + '/' + editing, { method: 'PUT', headers: headers(), body: JSON.stringify(form) })
      .then(async r => {
        const d = await r.json();
        if (!r.ok) throw Error(d.message);
        if (d.dataWarnings && d.dataWarnings.length > 0) {
          setWarnings(d.dataWarnings);
          notify('Record modified — data warnings detected. Please review.', 'warning');
        } else {
          setWarnings([]);
          notify(d.message || 'Record modified.', 'info');
        }
        setEditing(null);
        setForm(emptyForm);
        load();
      })
      .catch(e => notify(e.message, 'error'));
  };

  const startEdit = p => {
    setEditing(p.qrCode);
    setForm({
      name: p.name || '', farm: p.farm || '', location: p.location || '',
      farmerPrice: p.farmerPrice || '', retailPrice: p.retailPrice || '',
      category: p.category || 'plant', emoji: p.emoji || '',
      productImage: p.productImage || '',
    });
    setWarnings([]);
  };

  const del = id => {
    if (!window.confirm('Delete this draft record?')) return;
    fetch(API + '/' + id, { method: 'DELETE', headers: headers() })
      .then(r => r.json())
      .then(d => { notify(d.message, 'info'); load(); })
      .catch(e => notify(e.message, 'error'));
  };

  /* ════════════ LOGIN SCREEN ════════════ */
  if (!inApp) return (
    <div className="login">
      <form onSubmit={login}>
        <img className="login-logo" src="/assets/farm-to-fork-logo.jpeg" alt="Farm to Fork logo" />
        <p>FARM TO FORK LEDGER — DEMO ACCESS</p>
        <h1>Sign in securely</h1>
        <div className="rolelist">
          {Object.keys(accounts).map(x => (
            <button type="button" className={x === role ? 'active' : ''} onClick={() => choose(x)} key={x}>
              {accounts[x][0]}
            </button>
          ))}
        </div>
        <label>Username<input value={u} onChange={e => setU(e.target.value)} /></label>
        <label>Password<input type="password" value={pw} onChange={e => setPw(e.target.value)} /></label>
        <button className="primary">Sign in</button>
        {role === 'farmer' && (
          <div className="phone-help">
            <b>📞 No smartphone? Register by phone</b>
            <span>For this demo, farmers can contact USDA's produce-industry/PACA assistance line:</span>
            <a href="tel:+18004957222">{USDA_NUMBER}</a>
            <small>Demo only. This is a real USDA AMS PACA contact number; it is not a FarmToFork helpline.</small>
          </div>
        )}
      </form>
    </div>
  );

  /* ════════════ MAIN APP ════════════ */
  return (
    <div className="app">
      {/* Header */}
      <header>
        <div className="navbrand">
          <img src="/assets/farm-to-fork-logo.jpeg" alt="Farm to Fork logo" />
          <b>Farm to Fork <small>VERIFIED LEDGER</small></b>
        </div>
        <button onClick={() => { setInApp(false); setWarnings([]); setMsg(''); }}>
          {accounts[role][0]} — Log out
        </button>
      </header>

      {/* Hero */}
      <section className="hero">
        <p>SECURE TRANSPARENCY WORKSPACE</p>
        <h1>{accounts[role][0]}</h1>
        <span>Two-step verification: farmer submission → simulated USDA review → supply-chain handoffs.</span>
      </section>

      {/* Farmer phone banner */}
      {role === 'farmer' && (
        <section className="phone-banner">
          <div>
            <b>📞 Farmer phone registration</b>
            <span>No smartphone? Call the demo USDA produce-industry assistance line.</span>
          </div>
          <a href="tel:+18004957222">Call {USDA_NUMBER}</a>
          <small>Demo: USDA AMS/PACA assistance. Not a FarmToFork registration hotline.</small>
        </section>
      )}

      {/* ── QR Evidence: USDA only ── */}
      {role === 'usda' && (
        <section className="qr-evidence">
          <div>
            <p>QR EVIDENCE &amp; BATCH LOOKUP</p>
            <h2>Upload a product QR image</h2>
            <span>Upload a QR image to attach a traceability check to this USDA review session.</span>
          </div>
          <div className="upload-btn-group">
            {/* Gallery upload */}
            <label className="upload-box">
              <input
                type="file"
                accept="image/*"
                onChange={e => {
                  if (e.target.files[0]) {
                    setUsdaQrFile(e.target.files[0].name);
                    notify('✅ QR evidence uploaded: ' + e.target.files[0].name + ' — queued for ledger matching.', 'info');
                  }
                }}
              />
              <b>📁 Upload QR evidence</b>
              <small>{usdaQrFile ? `✅ ${usdaQrFile}` : 'PNG or JPG — from file'}</small>
            </label>
            {/* Camera capture */}
            <label className="upload-box upload-box-camera">
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={e => {
                  if (e.target.files[0]) {
                    setUsdaQrFile(e.target.files[0].name);
                    notify('✅ QR photo captured: ' + e.target.files[0].name + ' — queued for ledger matching.', 'info');
                  }
                }}
              />
              <b>📷 Camera scan</b>
              <small>Capture QR with camera</small>
            </label>
          </div>
        </section>
      )}

      {/* Security bar (non-consumer) */}
      {role !== 'consumer' && (
        <section className="security">
          <div><b>SECURITY CONTROLS</b><span>Role access, audit timestamps and record lifecycle checks enabled.</span></div>
          <div><b>DATA MATCHING</b><span>Origin, batch, pricing and standards are compared at each approval step.</span></div>
          <div><b>PRIVATE REVIEW PANEL</b><span>Operational notes are hidden from consumer accounts.</span></div>
        </section>
      )}

      {/* Toast / Alert */}
      {msg && (
        <div className={`toast toast-${msgType}`}>
          {msg}
          <button onClick={() => setMsg('')}>×</button>
        </div>
      )}

      {/* ── Data Mismatch Warnings ── */}
      {warnings.length > 0 && (
        <div className="alert-warning">
          <div className="alert-warning-header">
            <span>⚠️ DATA MISMATCH DETECTED</span>
            <button onClick={() => setWarnings([])}>Dismiss</button>
          </div>
          <p>The following issues were found in the submitted data. Please review and correct before final submission to USDA:</p>
          <ul>
            {warnings.map((w, i) => <li key={i}>{w}</li>)}
          </ul>
        </div>
      )}

      {/* ════ CONSUMER VIEW ════ */}
      {role === 'consumer' && <ConsumerQRLookup />}

      {/* ════ STAFF VIEWS ════ */}
      {role !== 'consumer' && (
        <>
          {/* ── Entry Form (Farmer gets image upload too) ── */}
          <section className="entry">
            <h2>{editing ? 'Modify harvest record' : 'New harvest data entry'}</h2>
            <form onSubmit={editing ? edit : add}>
              {['name', 'farm', 'location', 'farmerPrice', 'retailPrice'].map(x => (
                <input
                  key={x}
                  required
                  placeholder={x.replace(/([A-Z])/g, ' $1')}
                  value={form[x]}
                  onChange={e => setForm({ ...form, [x]: e.target.value })}
                />
              ))}
              <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                <option value="plant">Plant-based</option>
                <option value="animal">Animal product</option>
              </select>
              <button className="primary">{editing ? 'Save modifications' : 'Create draft record'}</button>
              {editing && <button type="button" onClick={() => { setEditing(null); setForm(emptyForm); setWarnings([]); }}>Cancel</button>}
            </form>

            {/* ── Product Image Upload (Farmer only) ── */}
            {role === 'farmer' && (
              <ProductImageUpload
                imageUrl={form.productImage}
                onUploaded={url => setForm(f => ({ ...f, productImage: url }))}
              />
            )}

            <small>Add, modify and delete tools are intentionally hidden from Consumer accounts. Only draft records can be modified or deleted.</small>
          </section>

          {role === 'usda' && (
            <section className="entry">
              <h2>USDA demo review queue</h2>
              <p>Review submitted lots, compare declared data, then approve or request farmer corrections.</p>
            </section>
          )}

          {/* ── Search Bar ── */}
          <div style={{ maxWidth: 1100, margin: '18px auto', padding: '0 20px' }}>
            <ProductSearchBar onResults={setDisplayed} allProducts={items} />
          </div>

          {/* ── Product List ── */}
          <main>
            {displayed.length === 0 && items.length > 0 && (
              <p style={{ gridColumn: '1/-1', color: '#6b7280', textAlign: 'center', padding: '40px 0' }}>
                No products match your search. Try a different term.
              </p>
            )}
            {displayed.map(p => (
              <article key={p.qrCode}>
                <em style={{ background: STATUS_COLORS[p.status] || '#6b7280', color: 'white' }}>
                  {(p.status || 'in-transit').replace(/-/g, ' ')}
                </em>

                {/* Data warning badge on card */}
                {p.dataWarnings && p.dataWarnings.length > 0 && (
                  <div className="card-warning-badge" title={p.dataWarnings.join(' | ')}>
                    ⚠️ {p.dataWarnings.length} data warning{p.dataWarnings.length > 1 ? 's' : ''}
                  </div>
                )}

                {/* Product image thumbnail (if farmer uploaded one) */}
                {p.productImage && (
                  <img src={p.productImage} alt={p.name} className="card-product-img" />
                )}

                <h2>{p.emoji} {p.name}</h2>
                <p>{p.farm} — {p.location}<br />Batch: {p.batchId}</p>
                <div className="audit">
                  <b>Verification route</b>
                  <span>Farmer → USDA review → Aggregator → Retailer → Consumer</span>
                  <strong>{p.nextVerifier ? 'Awaiting ' + p.nextVerifier : 'Fully verified ✅'}</strong>
                </div>

                <div className="actions">
                  {role !== 'consumer' && p.status === 'draft' && (
                    <>
                      <button onClick={() => startEdit(p)}>Modify</button>
                      <button onClick={() => del(p.qrCode)}>Delete draft</button>
                    </>
                  )}
                  {role === 'farmer' && p.status === 'draft' && (
                    <button className="primary" onClick={() => call('/' + p.qrCode + '/submit-usda')}>Submit to USDA</button>
                  )}
                  {role === 'usda' && p.nextVerifier === 'usda' && (
                    <>
                      <button className="primary" onClick={() => call('/' + p.qrCode + '/usda-review', { approved: true, note: 'Demo USDA data review passed: lot, origin and declared standards matched.' })}>
                        Approve review
                      </button>
                      <button onClick={() => call('/' + p.qrCode + '/usda-review', { approved: false, note: 'Demo mismatch found: farmer must correct data and resubmit.' })}>
                        Request correction
                      </button>
                    </>
                  )}
                  {['aggregator', 'retailer'].includes(role) && p.nextVerifier === role && (
                    <button className="primary" onClick={() => call('/' + p.qrCode + '/verify', { role })}>Verify handoff</button>
                  )}
                </div>

                <details>
                  <summary>Transparency audit log</summary>
                  {(p.auditLog || []).map(a => (
                    <p key={a.id}>
                      <b>{a.action}</b> — {a.actor}<br />
                      <small>{a.note} — {new Date(a.timestamp).toLocaleString()}</small>
                    </p>
                  ))}
                  {(p.verifications || []).map((v, i) => (
                    <p key={i}><b>Verified:</b> {v.actor}<br /><small>{v.note}</small></p>
                  ))}
                </details>
              </article>
            ))}
          </main>
        </>
      )}
    </div>
  );
}
