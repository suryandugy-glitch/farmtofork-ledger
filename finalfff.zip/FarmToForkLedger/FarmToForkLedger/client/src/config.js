// Configuration for FarmToFork Ledger API endpoints
const isDev = process.env.NODE_ENV === 'development' && typeof window !== 'undefined' && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');

// In local dev, backend runs on port 5001. In production / Vercel, requests are relative to origin.
const BASE_URL = process.env.REACT_APP_API_BASE || (isDev ? 'http://localhost:5001' : '');

export const API_URL = `${BASE_URL}/api/products`;
export const UPLOAD_API_URL = `${BASE_URL}/api/upload`;

const config = {
  API_URL,
  UPLOAD_API_URL,
};

export default config;
