require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const path    = require('path');
const fs      = require('fs');
const multer  = require('multer');

const app  = express();
const PORT = process.env.PORT || 5000;

// ── Ensure uploads directory exists ──
const UPLOADS_DIR = path.join(__dirname, 'uploads', 'products');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  console.log('Created uploads/products directory');
}

// ── Multer storage — saves to server/uploads/products/ ──
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename:    (req, file, cb) => {
    const ext  = path.extname(file.originalname).toLowerCase() || '.jpg';
    const name = `product_${Date.now()}${ext}`;
    cb(null, name);
  },
});
const upload = multer({
  storage,
  limits:    { fileSize: 10 * 1024 * 1024 }, // 10 MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Only image files are allowed.'));
  },
});

// ── Middleware ──
app.use(cors());
app.use(express.json());

// ── Serve uploaded product images as static files ──
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── Image upload endpoint ──
// POST /api/upload  (field: "image")
app.post('/api/upload', upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No image file received.' });
  const imageUrl = `http://localhost:${PORT}/uploads/products/${req.file.filename}`;
  res.json({
    message:   'Image uploaded successfully.',
    imageUrl,
    filename:  req.file.filename,
    size:      req.file.size,
  });
});

// Handle multer errors
app.use((err, req, res, next) => {
  if (err.code === 'LIMIT_FILE_SIZE') return res.status(400).json({ message: 'File too large. Max 10 MB.' });
  if (err.message) return res.status(400).json({ message: err.message });
  next(err);
});

// ── API Routes ──
const productRoutes = require('./routes/products');
app.use('/api/products', productRoutes);

// ── Health check ──
app.get('/api/health', (req, res) => {
  res.json({ message: 'FarmToFork Ledger API is running!', status: 'OK' });
});

// ── Serve React build in production ──
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '..', 'client', 'build')));
  app.get('*', (req, res) =>
    res.sendFile(path.join(__dirname, '..', 'client', 'build', 'index.html'))
  );
}

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Uploads folder: ${UPLOADS_DIR}`);
});
