import React, { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import './App.css';
import ConsumerQRLookup from './components/ConsumerQRLookup';
import ProductSearchBar from './components/ProductSearchBar';
import AIMonitorModal from './components/AIMonitorModal';
import AIPricingAssistant from './components/AIPricingAssistant';
import MarketTicker from './components/MarketTicker';
import FluidMetricsBar from './components/FluidMetricsBar';
import QRQuickViewModal from './components/QRQuickViewModal';
import AIPriceSimulatorModal from './components/AIPriceSimulatorModal';
import BlockExplorerModal from './components/BlockExplorerModal';
import ProvenanceCertificateModal from './components/ProvenanceCertificateModal';

import { API_URL as API, UPLOAD_API_URL as UPLOAD_API } from './config';
const USDA_NUMBER = '1-800-495-7222';

const accounts = {
  farmer:     ['Farmer',               'farmer.demo',     'Farmer@123',     '🧑‍🌾', 'Harvest registration & fair farmgate pricing'],
  usda:       ['USDA Reviewer (demo)', 'usda.demo',       'USDA@123',       '🏛️', 'Standards compliance & food safety desk'],
  aggregator: ['Aggregator',           'aggregator.demo', 'Aggregator@123', '📦', 'Cold-chain transit & logistics verification'],
  retailer:   ['Retailer',             'retailer.demo',   'Retailer@123',   '🏪', 'Shelf intake & transparent consumer handoff'],
  consumer:   ['Consumer',             'consumer.demo',   'Consumer@123',   '🛒', 'Provenance tracing & price transparency portal'],
};

const emptyForm = {
  name: '', farm: '', location: '',
  farmerPrice: '', retailPrice: '',
  category: 'plant', emoji: '',
  productImage: '',
};

const STATUS_COLORS = {
  draft: '#f59e0b',
  'awaiting-usda': '#3b82f6',
  'usda-approved': '#10b981',
  'usda-correction-required': '#ef4444',
  'in-transit': '#8b5cf6',
  'fully-verified': '#059669',
};

const getProductImage = (product) => {
  if (!product) return null;
  if (product.productImage) return product.productImage;
  const name = (product.name || '').toLowerCase();
  if (name.includes('mango') || name.includes('alphonso')) return '/assets/mango.jpg';
  if (name.includes('milk')  || name.includes('dairy') || name.includes('gir')) return '/assets/milk.jpg';
  if (name.includes('honey')) return '/assets/honey.jpg';
  if (name.includes('strawberr') || name.includes('berry')) return '/assets/strawberry.jpg';
  if (name.includes('cheese') || name.includes('chevre')) return '/assets/cheese.jpg';
  if (name.includes('orange') || name.includes('citrus') || name.includes('mandarin')) return '/assets/orange.jpg';
  if (name.includes('apple') || name.includes('fuji') || name.includes('gala')) return '/assets/apple.jpg';
  if (name.includes('egg')   || name.includes('chicken') || name.includes('poultry')) return '/assets/eggs.jpg';
  if (name.includes('tomato')) return '/assets/tomato.jpg';
  return null;
};

// Subtle Web Audio synthesizer for tactile UI interaction
const playHaptic = (type = 'click') => {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'success') {
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);
      osc.start();
      osc.stop(ctx.currentTime + 0.22);
    } else {
      osc.frequency.setValueAtTime(480, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);
      osc.start();
      osc.stop(ctx.currentTime + 0.06);
    }
  } catch (e) {}
};

/* ── Farmer Product Image Upload component ── */
function ProductImageUpload({ imageUrl, onUploaded }) {
  const galleryRef = useRef(null);
  const cameraRef  = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [uploadErr, setUploadErr] = useState('');

  const handleFile = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadErr('');
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('image', file);
      const res  = await fetch(UPLOAD_API, { method: 'POST', body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Upload failed.');
      onUploaded(data.imageUrl);
      playHaptic('success');
    } catch (err) {
      setUploadErr(err.message);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  return (
    <div className="prod-img-upload">
      <p className="prod-img-label">AUTHENTIC HARVEST PHOTOGRAPHY</p>

      {/* Preview */}
      {imageUrl ? (
        <div className="prod-img-preview-wrap">
          <img src={imageUrl} alt="Product" className="prod-img-preview" />
          <button
            type="button"
            className="prod-img-remove"
            onClick={() => onUploaded('')}
            title="Remove photo"
          >✕ Remove</button>
        </div>
      ) : (
        <div className="prod-img-placeholder">
          <span>📸</span>
          <small>Upload fresh harvest photo or select demo</small>
        </div>
      )}

      {/* Upload buttons */}
      <div className="prod-img-btns">
        <label className="prod-img-btn" title="Choose from files">
          <input
            ref={galleryRef}
            type="file"
            accept="image/*"
            onChange={handleFile}
            style={{ display: 'none' }}
          />
          {uploading ? '⏳ Uploading…' : '📁 Upload Photo'}
        </label>

        <label className="prod-img-btn prod-img-btn-camera" title="Take a photo with camera">
          <input
            ref={cameraRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleFile}
            style={{ display: 'none' }}
          />
          📷 Take Camera Photo
        </label>
      </div>

      {uploadErr && <small className="prod-img-err">⚠️ {uploadErr}</small>}
      <small className="prod-img-hint">
        Encrypted &amp; linked to batch hash on ledger. Max 10 MB.
      </small>
    </div>
  );
}

export default function App() {
  const [role, setRole]           = useState('farmer');
  const [u, setU]                 = useState('farmer.demo');
  const [pw, setPw]               = useState('Farmer@123');
  const [inApp, setInApp]         = useState(false);
  const [items, setItems]         = useState([]);
  const [displayed, setDisplayed] = useState([]);
  const [activeFilter, setActiveFilter] = useState('all');
  const [msg, setMsg]             = useState('');
  const [msgType, setMsgType]     = useState('info');
  const [form, setForm]           = useState(emptyForm);
  const [editing, setEditing]     = useState(null);
  const [warnings, setWarnings]   = useState([]);

  // Modals & Enhanced Features
  const [showAIMonitor, setShowAIMonitor]       = useState(false);
  const [showQRGallery, setShowQRGallery]       = useState(false);
  const [showSimulator, setShowSimulator]       = useState(false);
  const [showExplorer, setShowExplorer]         = useState(false);
  const [selectedCertProduct, setSelectedCertProduct] = useState(null);

  const [consumerPrefillCode, setConsumerPrefillCode] = useState('');
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('ftf_theme') === 'dark');

  // USDA QR evidence upload state
  const [usdaQrFile, setUsdaQrFile] = useState('');

  const toggleTheme = () => {
    playHaptic('click');
    setDarkMode(d => {
      const next = !d;
      localStorage.setItem('ftf_theme', next ? 'dark' : 'light');
      return next;
    });
  };

  const headers = () => ({ 'Content-Type': 'application/json', 'x-user-role': role });

  const load = useCallback(() => {
    fetch(API, { headers: headers() })
      .then(r => r.json())
      .then(data => {
        setItems(data);
        setDisplayed(data);
      })
      .catch(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [role]);

  useEffect(() => { if (inApp) load(); }, [inApp, load]);

  const choose = x => {
    playHaptic('click');
    setRole(x);
    setU(accounts[x][1]);
    setPw(accounts[x][2]);
    setEditing(null);
    setWarnings([]);
  };

  const login = e => {
    if (e) e.preventDefault();
    playHaptic('success');
    const a = accounts[role];
    if (u !== a[1] || pw !== a[2]) return notify('Use the pre-filled demo credentials.', 'error');
    setInApp(true);
    setMsg('');
  };

  const quickLaunchRole = (targetRole, initialCode = '') => {
    playHaptic('click');
    setRole(targetRole);
    setU(accounts[targetRole][1]);
    setPw(accounts[targetRole][2]);
    setInApp(true);
    if (initialCode) {
      setConsumerPrefillCode(initialCode);
    }
    setMsg('');
  };

  const notify = (text, type = 'info') => { setMsg(text); setMsgType(type); };

  const call = (path, body) => {
    playHaptic('click');
    fetch(API + path, { method: 'POST', headers: headers(), body: JSON.stringify(body || {}) })
      .then(async r => {
        const d = await r.json();
        if (!r.ok) throw Error(d.message);
        playHaptic('success');
        if (d.dataWarnings && d.dataWarnings.length > 0) {
          setWarnings(d.dataWarnings);
          notify('Ledger updated — data warnings detected. Please review.', 'warning');
        } else {
          notify(d.message || 'Ledger updated securely.', 'info');
        }
        load();
      })
      .catch(e => notify(e.message, 'error'));
  };

  const add = e => {
    e.preventDefault();
    playHaptic('click');
    fetch(API, { method: 'POST', headers: headers(), body: JSON.stringify(form) })
      .then(async r => {
        const d = await r.json();
        if (!r.ok) throw Error(d.message);
        playHaptic('success');
        if (d.dataWarnings && d.dataWarnings.length > 0) {
          setWarnings(d.dataWarnings);
          notify('Draft created — data warnings detected. Review alert below.', 'warning');
        } else {
          setWarnings([]);
          notify('Draft harvest record created successfully.', 'info');
        }
        setForm(emptyForm);
        load();
      })
      .catch(e => notify(e.message, 'error'));
  };

  const edit = e => {
    e.preventDefault();
    playHaptic('click');
    fetch(API + '/' + editing, { method: 'PUT', headers: headers(), body: JSON.stringify(form) })
      .then(async r => {
        const d = await r.json();
        if (!r.ok) throw Error(d.message);
        playHaptic('success');
        if (d.dataWarnings && d.dataWarnings.length > 0) {
          setWarnings(d.dataWarnings);
          notify('Record modified — data warnings detected.', 'warning');
        } else {
          setWarnings([]);
          notify(d.message || 'Record modified.', 'info');
        }
        setEditing(null);
        setForm(emptyForm);
        load();
      })
      .catch(e => notify(e.message, 'error'));
  };

  const startEdit = p => {
    playHaptic('click');
    setEditing(p.qrCode);
    setForm({
      name: p.name || '', farm: p.farm || '', location: p.location || '',
      farmerPrice: p.farmerPrice || '', retailPrice: p.retailPrice || '',
      category: p.category || 'plant', emoji: p.emoji || '',
      productImage: p.productImage || '',
    });
    setWarnings([]);
    window.scrollTo({ top: 350, behavior: 'smooth' });
  };

  const del = id => {
    if (!window.confirm('Delete this draft record?')) return;
    playHaptic('click');
    fetch(API + '/' + id, { method: 'DELETE', headers: headers() })
      .then(r => r.json())
      .then(d => { notify(d.message, 'info'); load(); })
      .catch(e => notify(e.message, 'error'));
  };

  // Filter logic
  const filteredProducts = useMemo(() => {
    return displayed.filter(p => {
      if (activeFilter === 'all') return true;
      if (activeFilter === 'plant') return p.category === 'plant';
      if (activeFilter === 'animal') return p.category === 'animal';
      if (activeFilter === 'verified') return p.status === 'fully-verified';
      if (activeFilter === 'transit') return p.status === 'in-transit';
      if (activeFilter === 'warning') return (p.dataWarnings && p.dataWarnings.length > 0);
      return true;
    });
  }, [displayed, activeFilter]);

  const plantCount = items.filter(p => p.category === 'plant').length;
  const animalCount = items.filter(p => p.category === 'animal').length;
  const verifiedCount = items.filter(p => p.status === 'fully-verified').length;
  const transitCount = items.filter(p => p.status === 'in-transit').length;

  /* ════════════ LOGIN SCREEN ════════════ */
  if (!inApp) return (
    <div className={`login-fluid-container ${darkMode ? 'theme-dark' : 'theme-light'}`}>
      {/* Live Market Ticker on Landing Screen */}
      <MarketTicker
        onSelectProduct={(name) => {
          quickLaunchRole('consumer');
        }}
      />

      <div className="login-fluid-wrap">
        <div className="login-ambient-orb orb-1" />
        <div className="login-ambient-orb orb-2" />

        <form onSubmit={login} className="login-fluid-card">
          <div className="login-brand-header">
            <div className="login-logo-ring">
              <img className="login-logo" src="/assets/farm-to-fork-logo.jpeg" alt="Farm to Fork logo" />
              <span className="login-logo-glow" />
            </div>
            <span className="login-kicker">DECENTRALIZED SUPPLY CHAIN &amp; AI PRICING</span>
            <h1>FarmToFork Ledger</h1>
            <p className="login-subtitle">
              Cryptographic food traceability with Hedonic AI fairness engine.
            </p>
          </div>

          {/* Action pills: AI Monitor, QR Demo, Simulator & Explorer */}
          <div className="login-quick-actions">
            <button
              type="button"
              className="ai-login-pill"
              onClick={() => { playHaptic('click'); setShowAIMonitor(true); }}
              title="Inspect AI Valuation & Background Audit Model"
            >
              <span className="ai-pulsing-green" />
              AI Model: <b>ACTIVE</b> ↗
            </button>

            <button
              type="button"
              className="qr-login-pill"
              onClick={() => { playHaptic('click'); setShowQRGallery(true); }}
              title="Inspect scannable demo QR codes"
            >
              <span>⚡</span>
              <b>9 Demo QRs</b> ↗
            </button>

            <button
              type="button"
              className="btn-pill-feature"
              onClick={() => { playHaptic('click'); setShowSimulator(true); }}
              title="Launch AI Price & Margin Simulator"
            >
              <span>🔮</span>
              <b>AI Simulator</b>
            </button>

            <button
              type="button"
              className="btn-pill-feature"
              onClick={() => { playHaptic('click'); setShowExplorer(true); }}
              title="Launch Blockchain Block Explorer"
            >
              <span>⛓️</span>
              <b>Ledger</b>
            </button>
          </div>

          <div className="role-selector-label">
            <span>SELECT ACCESS ROLE:</span>
            <small>{accounts[role][4]}</small>
          </div>

          <div className="rolelist-fluid">
            {Object.keys(accounts).map(x => (
              <button
                type="button"
                className={`role-btn-card ${x === role ? 'active' : ''}`}
                onClick={() => choose(x)}
                key={x}
              >
                <span className="role-btn-emoji">{accounts[x][3]}</span>
                <span className="role-btn-name">{accounts[x][0]}</span>
              </button>
            ))}
          </div>

          <div className="login-input-group">
            <label>
              <span>DEMO USERNAME</span>
              <input value={u} onChange={e => setU(e.target.value)} required />
            </label>
            <label>
              <span>PASSWORD</span>
              <input type="password" value={pw} onChange={e => setPw(e.target.value)} required />
            </label>
          </div>

          <div className="login-btn-row">
            <button type="submit" className="primary login-submit-btn">
              Sign In as {accounts[role][0]} →
            </button>
          </div>

          <div className="login-demo-shortcuts">
            <small>Instant 1-Click Role Access:</small>
            <div className="shortcut-chips">
              <button type="button" onClick={() => quickLaunchRole('consumer')}>
                🛒 Consumer Portal
              </button>
              <button type="button" onClick={() => quickLaunchRole('farmer')}>
                🧑‍🌾 Farmer Hub
              </button>
              <button type="button" onClick={() => quickLaunchRole('usda')}>
                🏛️ USDA Review
              </button>
              <button type="button" onClick={() => quickLaunchRole('aggregator')}>
                📦 Aggregator
              </button>
              <button type="button" onClick={() => quickLaunchRole('retailer')}>
                🏪 Retailer
              </button>
            </div>
          </div>

          {role === 'farmer' && (
            <div className="phone-help-fluid">
              <b>📞 Offline Farmer Hotline (Demo USDA PACA):</b>
              <a href="tel:+18004957222">{USDA_NUMBER}</a>
              <small>Dial for produce industry &amp; fair price dispute assistance.</small>
            </div>
          )}
        </form>
      </div>

      <AIMonitorModal isOpen={showAIMonitor} onClose={() => setShowAIMonitor(false)} />
      <QRQuickViewModal
        isOpen={showQRGallery}
        onClose={() => setShowQRGallery(false)}
        onSelectQRForConsumer={(code) => quickLaunchRole('consumer', code)}
      />
      <AIPriceSimulatorModal
        isOpen={showSimulator}
        onClose={() => setShowSimulator(false)}
        onApplyToForm={(name, fPrice, rPrice) => {
          quickLaunchRole('farmer');
          setForm(f => ({ ...f, name, farmerPrice: String(fPrice), retailPrice: String(rPrice) }));
        }}
      />
      <BlockExplorerModal
        isOpen={showExplorer}
        onClose={() => setShowExplorer(false)}
      />
    </div>
  );

  /* ════════════ MAIN APP ════════════ */
  return (
    <div className={`app-fluid-layout ${darkMode ? 'theme-dark' : 'theme-light'}`}>
      {/* ── Live Market Ticker ── */}
      <MarketTicker
        onSelectProduct={(name) => {
          if (role === 'consumer') {
            const match = items.find(p => p.name.toLowerCase().includes(name.toLowerCase().split(' ')[0]));
            if (match) setConsumerPrefillCode(match.qrCode);
          } else {
            const match = items.find(p => p.name.toLowerCase().includes(name.toLowerCase().split(' ')[0]));
            if (match) setDisplayed([match]);
          }
        }}
      />

      {/* ── Fluid Header ── */}
      <header className="fluid-header">
        <div className="navbrand-fluid">
          <div className="brand-logo-wrap">
            <img src="/assets/farm-to-fork-logo.jpeg" alt="Farm to Fork logo" />
            <span className="brand-verified-glow" />
          </div>
          <div className="brand-title-wrap">
            <b>Farm to Fork <span className="brand-badge-pill">LEDGER 2.0</span></b>
            <small>IMMUTABLE PROVENANCE &amp; HEDONIC AI PRICING</small>
          </div>
        </div>

        <div className="header-actions-fluid">
          {/* Quick Feature Buttons */}
          <button
            type="button"
            className="btn-header-feature"
            onClick={() => { playHaptic('click'); setShowSimulator(true); }}
            title="Launch Interactive AI Price Simulator & Margin Calculator"
          >
            <span className="btn-sparkle-icon">🔮</span>
            <b>AI Simulator</b>
          </button>

          <button
            type="button"
            className="btn-header-feature"
            onClick={() => { playHaptic('click'); setShowExplorer(true); }}
            title="Inspect Distributed Blockchain Blocks & Consensus Proofs"
          >
            <span className="btn-sparkle-icon">⛓️</span>
            <b>Block Explorer</b>
          </button>

          <button
            type="button"
            className="btn-header-qr"
            onClick={() => { playHaptic('click'); setShowQRGallery(true); }}
            title="Inspect Scannable QR Codes for All Products"
          >
            <span className="qr-spark-icon">⚡</span>
            <b>QR Gallery (9)</b>
          </button>

          {/* AI Background Auditor Button */}
          <button
            type="button"
            className="ai-header-btn-fluid"
            onClick={() => { playHaptic('click'); setShowAIMonitor(true); }}
            title="Inspect autonomous AI background audit worker"
          >
            <span className="ai-pulsing-green" />
            <div className="ai-btn-text">
              <b>AI Engine: Active</b>
              <small>Autonomous Auditor ↗</small>
            </div>
          </button>

          {/* Theme Switcher Toggle */}
          <button
            type="button"
            className="btn-theme-toggle"
            onClick={toggleTheme}
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {darkMode ? '☀️ Light' : '🌙 Dark'}
          </button>

          {/* Role pill & Log out */}
          <div className="user-role-badge">
            <span className="role-emoji">{accounts[role][3]}</span>
            <span className="role-title">{accounts[role][0]}</span>
          </div>

          <button
            className="btn-logout-fluid"
            onClick={() => { playHaptic('click'); setInApp(false); setWarnings([]); setMsg(''); }}
            title="Switch demo account"
          >
            Switch Account
          </button>
        </div>
      </header>

      {/* ── Quick 1-Click Role Switcher Ribbon (Direct Header Sub-bar) ── */}
      <div className="quick-role-ribbon">
        <div className="quick-role-inner">
          <span className="quick-role-label">QUICK SWITCH ROLE:</span>
          <div className="quick-role-btns">
            {Object.keys(accounts).map(rKey => (
              <button
                key={rKey}
                type="button"
                className={`quick-role-btn ${rKey === role ? 'active' : ''}`}
                onClick={() => choose(rKey)}
              >
                <span>{accounts[rKey][3]}</span>
                <b>{accounts[rKey][0]}</b>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── Fluid Hero Banner ── */}
      <section className="fluid-hero">
        <div className="fluid-hero-inner">
          <div className="hero-kicker-row">
            <span className="hero-kicker-pill">DECENTRALIZED AGRI-VALUE CHAIN</span>
            <span className="hero-role-chip">{accounts[role][3]} {accounts[role][0]} Workspace</span>
          </div>
          <h1>
            {role === 'farmer' && 'Direct Farmer Intake & Fair Pricing'}
            {role === 'usda' && 'USDA Food Safety & Standards Review'}
            {role === 'aggregator' && 'Cold-Chain Logistics & Quality Handoff'}
            {role === 'retailer' && 'Retail Shelf Intake & Transparency Display'}
            {role === 'consumer' && 'Consumer Provenance & Fair Price Audit'}
          </h1>
          <p className="hero-desc">
            Two-step cryptographic verification: Farmer origin lot submission → Independent USDA review → Cold-chain aggregation → Retail shelf → Consumer QR scan.
          </p>
        </div>
      </section>

      {/* ── Interactive KPI Metrics Bar ── */}
      <FluidMetricsBar
        items={items}
        onOpenAIMonitor={() => setShowAIMonitor(true)}
        onOpenQRGallery={() => setShowQRGallery(true)}
      />

      {/* Farmer phone banner */}
      {role === 'farmer' && (
        <section className="phone-banner-fluid">
          <div className="phone-banner-content">
            <span className="phone-banner-icon">📞</span>
            <div>
              <b>Farmer Voice &amp; SMS Intake (Demo PACA Desk)</b>
              <span>No smartphone or field connectivity? Connect with USDA AMS produce verification desk.</span>
            </div>
          </div>
          <a href="tel:+18004957222" className="phone-banner-action">Call {USDA_NUMBER}</a>
        </section>
      )}

      {/* ── QR Evidence: USDA only ── */}
      {role === 'usda' && (
        <section className="qr-evidence-fluid">
          <div>
            <span className="section-label">QR EVIDENCE &amp; CRYPTOGRAPHIC BATCH LOOKUP</span>
            <h2>Inspect Harvest Lot QR Evidence</h2>
            <p>Upload a physical product QR photo to cross-reference with USDA AMS pesticide and soil standards.</p>
          </div>
          <div className="upload-btn-group-fluid">
            <label className="upload-box-fluid">
              <input
                type="file"
                accept="image/*"
                onChange={e => {
                  if (e.target.files[0]) {
                    setUsdaQrFile(e.target.files[0].name);
                    notify('✅ QR evidence uploaded: ' + e.target.files[0].name + ' — queued for ledger matching.', 'info');
                  }
                }}
              />
              <span className="upload-box-icon">📁</span>
              <b>Upload QR Evidence</b>
              <small>{usdaQrFile ? `✅ ${usdaQrFile}` : 'PNG / JPG from filesystem'}</small>
            </label>

            <label className="upload-box-fluid upload-box-camera">
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={e => {
                  if (e.target.files[0]) {
                    setUsdaQrFile(e.target.files[0].name);
                    notify('✅ QR photo captured: ' + e.target.files[0].name + ' — queued for ledger matching.', 'info');
                  }
                }}
              />
              <span className="upload-box-icon">📷</span>
              <b>Camera Live Scan</b>
              <small>Capture directly with camera</small>
            </label>
          </div>
        </section>
      )}

      {/* Toast / Alert */}
      {msg && (
        <div className={`toast-fluid toast-${msgType}`}>
          <span className="toast-icon">{msgType === 'error' ? '⚠️' : '✅'}</span>
          <span className="toast-text">{msg}</span>
          <button onClick={() => setMsg('')} className="toast-close">✕</button>
        </div>
      )}

      {/* ── Data Mismatch Warnings ── */}
      {warnings.length > 0 && (
        <div className="alert-warning-fluid">
          <div className="alert-warning-header">
            <span>⚠️ LEDGER INTEGRITY NOTICE</span>
            <button onClick={() => setWarnings([])}>Dismiss</button>
          </div>
          <p>Discrepancies identified during validation against regional benchmark data:</p>
          <ul>
            {warnings.map((w, i) => <li key={i}>{w}</li>)}
          </ul>
        </div>
      )}

      {/* ════ CONSUMER VIEW ════ */}
      {role === 'consumer' && (
        <ConsumerQRLookup initialCode={consumerPrefillCode} />
      )}

      {/* ════ STAFF VIEWS ════ */}
      {role !== 'consumer' && (
        <>
          {/* ── Entry Form (Farmer gets image upload & AI pricing assistant) ── */}
          <section className="entry-fluid">
            <div className="entry-header-row">
              <div>
                <span className="section-label">BLOCKCHAIN TRANSACTION ENTRY</span>
                <h2>{editing ? 'Modify Harvest Record' : 'Log New Harvest Lot to Ledger'}</h2>
              </div>
              <div className="entry-header-actions">
                <button
                  type="button"
                  className="btn-launch-sim"
                  onClick={() => setShowSimulator(true)}
                  title="Simulate Fair Price Bands Before Submitting"
                >
                  🔮 Launch Price Simulator
                </button>
                {role === 'farmer' && (
                  <span className="entry-role-tag">🧑‍🌾 Verified Farmer Authority</span>
                )}
              </div>
            </div>

            <form onSubmit={editing ? edit : add} className="entry-form-grid">
              <div className="form-field">
                <label>Commodity Name</label>
                <input
                  required
                  placeholder="e.g. Ratnagiri Alphonso Mangoes"
                  value={form.name}
                  onChange={e => setForm({ ...form, name: e.target.value })}
                />
              </div>

              <div className="form-field">
                <label>Farm &amp; Producer Name</label>
                <input
                  required
                  placeholder="e.g. Konkan Orchard Groves"
                  value={form.farm}
                  onChange={e => setForm({ ...form, farm: e.target.value })}
                />
              </div>

              <div className="form-field">
                <label>Origin Location &amp; Region</label>
                <input
                  required
                  placeholder="e.g. Ratnagiri, Maharashtra"
                  value={form.location}
                  onChange={e => setForm({ ...form, location: e.target.value })}
                />
              </div>

              <div className="form-field">
                <label>Original Farmgate Price (₹)</label>
                <input
                  required
                  type="number"
                  placeholder="e.g. 550"
                  value={form.farmerPrice}
                  onChange={e => setForm({ ...form, farmerPrice: e.target.value })}
                />
              </div>

              <div className="form-field">
                <label>Target Retail Price (₹)</label>
                <input
                  required
                  type="number"
                  placeholder="e.g. 1150"
                  value={form.retailPrice}
                  onChange={e => setForm({ ...form, retailPrice: e.target.value })}
                />
              </div>

              <div className="form-field">
                <label>Category</label>
                <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
                  <option value="plant">🌿 Plant-Based / Fruits / Grain</option>
                  <option value="animal">🐄 Dairy / Eggs / Animal-Based</option>
                </select>
              </div>

              <div className="form-submit-row">
                <button type="submit" className="primary btn-submit-harvest">
                  {editing ? '💾 Save Ledger Modifications' : '⚡ Publish Draft Harvest Lot'}
                </button>
                {editing && (
                  <button type="button" className="btn-cancel-edit" onClick={() => { setEditing(null); setForm(emptyForm); setWarnings([]); }}>
                    Cancel
                  </button>
                )}
              </div>
            </form>

            {/* ── Live AI Pricing Assistant (Farmer & Staff) ── */}
            <AIPricingAssistant
              form={form}
              onApplyRecommendedPrice={price => setForm(f => ({ ...f, farmerPrice: String(price) }))}
            />

            {/* ── Product Image Upload (Farmer only) ── */}
            {role === 'farmer' && (
              <ProductImageUpload
                imageUrl={form.productImage}
                onUploaded={url => setForm(f => ({ ...f, productImage: url }))}
              />
            )}

            <div className="entry-footer-hint">
              <span>🔒 Consumer accounts have read-only transparency rights. Modifications require cryptographically authorized staff roles.</span>
            </div>
          </section>

          {/* ── Search & Fluid Filter Ribbon ── */}
          <div className="catalog-toolbar-wrap">
            <ProductSearchBar onResults={setDisplayed} allProducts={items} />

            {/* Fluid Category Filter Pills */}
            <div className="fluid-filter-ribbon">
              {[
                { key: 'all', label: `All Batches (${items.length})` },
                { key: 'plant', label: `🌿 Plant Produce (${plantCount})` },
                { key: 'animal', label: `🐄 Dairy & Animal (${animalCount})` },
                { key: 'verified', label: `✅ Fully Verified (${verifiedCount})` },
                { key: 'transit', label: `🚚 In-Transit (${transitCount})` },
                { key: 'warning', label: '⚠️ Review Notices' },
              ].map(tab => (
                <button
                  key={tab.key}
                  className={`fluid-filter-pill ${activeFilter === tab.key ? 'active' : ''}`}
                  onClick={() => { playHaptic('click'); setActiveFilter(tab.key); }}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* ── Fluid Product Catalog Grid ── */}
          <main className="fluid-product-grid">
            {filteredProducts.length === 0 && items.length > 0 && (
              <div className="empty-catalog-state">
                <span className="empty-icon">🔍</span>
                <h3>No batches match this filter criteria</h3>
                <p>Try switching filter tabs or clearing your search keywords.</p>
                <button className="primary-sm" onClick={() => setActiveFilter('all')}>
                  Reset Filter to All
                </button>
              </div>
            )}

            {filteredProducts.map(p => {
              const pImg = getProductImage(p);
              const farmerSharePct = p.farmerPrice && p.retailPrice
                ? Math.round((p.farmerPrice / p.retailPrice) * 100)
                : 40;
              const aggMargin = p.aggregatorMargin || Math.round(p.retailPrice * 0.2);
              const aggSharePct = p.retailPrice ? Math.round((aggMargin / p.retailPrice) * 100) : 25;
              const retMargin = p.retailerMargin || (p.retailPrice - p.farmerPrice - aggMargin);
              const retSharePct = Math.max(0, 100 - farmerSharePct - aggSharePct);

              return (
                <article key={p.qrCode} className="fluid-product-card">
                  {/* Card Header Media */}
                  <div className="card-media-wrap">
                    {pImg ? (
                      <img src={pImg} alt={p.name} className="card-product-img-fluid" />
                    ) : (
                      <div className="card-placeholder-img">
                        <span className="card-placeholder-emoji">{p.emoji || '🌾'}</span>
                      </div>
                    )}

                    <div className="card-floating-badges">
                      <span
                        className="card-status-pill"
                        style={{ background: STATUS_COLORS[p.status] || '#6b7280' }}
                      >
                        <span className="status-ping-dot" />
                        {(p.status || 'in-transit').replace(/-/g, ' ')}
                      </span>

                      <span className="card-category-pill">
                        {p.category === 'animal' ? '🐄 Animal' : '🌿 Plant'}
                      </span>
                    </div>

                    <div className="card-batch-overlay">
                      <code>{p.batchId}</code>
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="card-content-wrap">
                    {/* Title & Origin */}
                    <div className="card-title-row">
                      <h2>
                        <span className="product-emoji">{p.emoji}</span>
                        {p.name}
                      </h2>
                    </div>

                    <div className="card-location-row">
                      <span className="pin-icon">📍</span>
                      <span className="card-farm-text"><b>{p.farm}</b> • {p.location}</span>
                    </div>

                    {/* Supply Chain Micro-Route Badge */}
                    <div className="card-route-micro">
                      <span className="crm-node">🧑‍🌾 Harvested</span>
                      <span className="crm-arrow">➔</span>
                      <span className="crm-node">🏛️ USDA Standard</span>
                      <span className="crm-arrow">➔</span>
                      <span className="crm-node">❄️ Cold-Chain 4°C</span>
                    </div>

                    {/* AI Assessment Badge */}
                    {p.aiAssessment && (
                      <div
                        className={`fluid-ai-card-pill ai-status-${p.aiAssessment.pricingComparison?.fairnessStatus || 'fair'}`}
                        onClick={() => { playHaptic('click'); setShowAIMonitor(true); }}
                        title={p.aiAssessment.farmerVerdict}
                      >
                        <span className="ai-icon">🤖</span>
                        <div className="ai-pill-info">
                          <b>
                            {p.aiAssessment.pricingComparison?.fairnessStatus === 'fair'
                              ? `AI Fair Value (₹${p.farmerPrice})`
                              : p.aiAssessment.pricingComparison?.fairnessStatus === 'underpriced_warning'
                              ? `⚠️ Farmgate Underpriced (₹${p.farmerPrice})`
                              : `Fairness Notice (${p.aiAssessment.pricingComparison?.actualFarmerSharePct}%)`}
                          </b>
                          <small>Hedonic Score: {p.aiAssessment.fairnessScore ?? 92}/100 ↗</small>
                        </div>
                      </div>
                    )}

                    {/* Data Warnings */}
                    {p.dataWarnings && p.dataWarnings.length > 0 && (
                      <div className="card-warning-pill" title={p.dataWarnings.join(' | ')}>
                        ⚠️ {p.dataWarnings.length} validation discrepancy detected
                      </div>
                    )}

                    {/* Fluid Revenue Margin Stacked Bar */}
                    <div className="card-revenue-bar-box">
                      <div className="crb-header">
                        <span>PRICE ARCHITECTURE</span>
                        <b>₹{p.retailPrice} Retail</b>
                      </div>

                      <div className="crb-stacked-bar">
                        <div
                          className="crb-segment farmer-seg"
                          style={{ width: `${farmerSharePct}%` }}
                          title={`Farmer Share: ₹${p.farmerPrice} (${farmerSharePct}%)`}
                        />
                        <div
                          className="crb-segment agg-seg"
                          style={{ width: `${aggSharePct}%` }}
                          title={`Aggregator Margin: ₹${aggMargin} (${aggSharePct}%)`}
                        />
                        <div
                          className="crb-segment ret-seg"
                          style={{ width: `${retSharePct}%` }}
                          title={`Retailer Margin: ₹${retMargin} (${retSharePct}%)`}
                        />
                      </div>

                      <div className="crb-legend">
                        <span className="crb-legend-item farmer">
                          <i /> Farmer: <b>₹{p.farmerPrice}</b> ({farmerSharePct}%)
                        </span>
                        <span className="crb-legend-item agg">
                          <i /> Agg: <b>₹{aggMargin}</b>
                        </span>
                        <span className="crb-legend-item ret">
                          <i /> Ret: <b>₹{retMargin}</b>
                        </span>
                      </div>
                    </div>

                    {/* Verification Route & Block Hash */}
                    <div className="audit-route-box">
                      <div className="audit-route-header">
                        <span>CONSENSUS PROOF</span>
                        <strong>{p.nextVerifier ? '⏳ Awaiting ' + p.nextVerifier : '✅ Fully Verified'}</strong>
                      </div>
                      <div className="audit-hash-row">
                        <span>Hash:</span>
                        <code>{p.blockchainHash || '0xa3f5c7d8e2b1f94c9c2e'}</code>
                      </div>
                    </div>

                    {/* Actions Toolbar */}
                    <div className="card-action-bar">
                      {role !== 'consumer' && p.status === 'draft' && (
                        <>
                          <button className="btn-card-action" onClick={() => startEdit(p)}>✏️ Edit</button>
                          <button className="btn-card-action btn-danger" onClick={() => del(p.qrCode)}>🗑️ Delete</button>
                        </>
                      )}

                      {role === 'farmer' && p.status === 'draft' && (
                        <button className="primary btn-card-primary" onClick={() => call('/' + p.qrCode + '/submit-usda')}>
                          Submit to USDA Desk →
                        </button>
                      )}

                      {role === 'usda' && p.nextVerifier === 'usda' && (
                        <div className="usda-card-actions">
                          <button
                            className="primary btn-card-primary"
                            onClick={() => call('/' + p.qrCode + '/usda-review', { approved: true, note: 'USDA Food Safety review passed: pesticide & origin certified.' })}
                          >
                            ✓ Approve Review
                          </button>
                          <button
                            className="btn-card-action btn-warn"
                            onClick={() => call('/' + p.qrCode + '/usda-review', { approved: false, note: 'Specification mismatch: farmer must adjust harvest lot.' })}
                          >
                            Correction
                          </button>
                        </div>
                      )}

                      {['aggregator', 'retailer'].includes(role) && p.nextVerifier === role && (
                        <button className="primary btn-card-primary" onClick={() => call('/' + p.qrCode + '/verify', { role })}>
                          Verify {role.toUpperCase()} Handoff →
                        </button>
                      )}

                      {/* Quick Feature Buttons: View QR, Consumer View, Certificate */}
                      <div className="card-feature-btn-row">
                        <button
                          type="button"
                          className="btn-card-qr"
                          onClick={() => { playHaptic('click'); setShowQRGallery(true); }}
                          title="Inspect scannable QR Code"
                        >
                          ⚡ QR Code
                        </button>

                        <button
                          type="button"
                          className="btn-card-cert"
                          onClick={() => { playHaptic('click'); setSelectedCertProduct(p); }}
                          title="Generate Official Provenance Certificate"
                        >
                          📜 Certificate
                        </button>

                        <button
                          type="button"
                          className="btn-card-inspect"
                          onClick={() => quickLaunchRole('consumer', p.qrCode)}
                          title="Inspect as Consumer"
                        >
                          🔍 Consumer
                        </button>
                      </div>
                    </div>

                    {/* Collapsible Transparency Audit Log */}
                    <details className="card-audit-details">
                      <summary>
                        <span>📜 Provenance Trail ({((p.auditLog || []).length) + ((p.verifications || []).length)} entries)</span>
                      </summary>
                      <div className="card-audit-inner">
                        {(p.verifications || []).map((v, i) => (
                          <div key={'v-' + i} className="card-audit-line verified">
                            <b>✅ {v.actor}</b>
                            <p>{v.note}</p>
                            <small>{v.timestamp ? new Date(v.timestamp).toLocaleString() : ''}</small>
                          </div>
                        ))}
                        {(p.auditLog || []).map(a => (
                          <div key={a.id} className="card-audit-line">
                            <b>{a.action}</b> — <span>{a.actor}</span>
                            <p>{a.note}</p>
                            <small>{new Date(a.timestamp).toLocaleString()}</small>
                          </div>
                        ))}
                      </div>
                    </details>
                  </div>
                </article>
              );
            })}
          </main>
        </>
      )}

      {/* ── Modals ── */}
      <AIMonitorModal isOpen={showAIMonitor} onClose={() => setShowAIMonitor(false)} />
      <QRQuickViewModal
        isOpen={showQRGallery}
        onClose={() => setShowQRGallery(false)}
        onSelectQRForConsumer={(code) => quickLaunchRole('consumer', code)}
      />
      <AIPriceSimulatorModal
        isOpen={showSimulator}
        onClose={() => setShowSimulator(false)}
        onApplyToForm={(name, fPrice, rPrice) => {
          quickLaunchRole('farmer');
          setForm(f => ({ ...f, name, farmerPrice: String(fPrice), retailPrice: String(rPrice) }));
        }}
      />
      <BlockExplorerModal
        isOpen={showExplorer}
        onClose={() => setShowExplorer(false)}
      />
      <ProvenanceCertificateModal
        isOpen={!!selectedCertProduct}
        onClose={() => setSelectedCertProduct(null)}
        product={selectedCertProduct}
      />
    </div>
  );
}
