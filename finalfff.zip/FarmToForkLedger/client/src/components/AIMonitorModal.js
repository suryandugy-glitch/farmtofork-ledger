import React, { useState, useEffect, useCallback } from 'react';
import { AI_API_URL } from '../config';

export default function AIMonitorModal({ isOpen, onClose }) {
  const [status, setStatus] = useState(null);
  const [comparison, setComparison] = useState(null);
  const [activeTab, setActiveTab] = useState('stream'); // 'stream' | 'comparison' | 'baselines'
  const [triggering, setTriggering] = useState(false);
  const [triggerMsg, setTriggerMsg] = useState('');

  const fetchStatus = useCallback(async () => {
    try {
      const res = await fetch(`${AI_API_URL}/status`);
      if (res.ok) {
        const data = await res.json();
        setStatus(data);
      }
    } catch (e) {
      console.warn('Could not fetch AI status:', e);
    }
  }, []);

  const fetchComparison = useCallback(async () => {
    try {
      const res = await fetch(`${AI_API_URL}/historical-comparison`);
      if (res.ok) {
        const data = await res.json();
        setComparison(data);
      }
    } catch (e) {
      console.warn('Could not fetch historical comparison:', e);
    }
  }, []);

  // Poll status while modal is open (every 3s)
  useEffect(() => {
    if (!isOpen) return;
    fetchStatus();
    fetchComparison();
    const interval = setInterval(() => {
      fetchStatus();
    }, 3000);
    return () => clearInterval(interval);
  }, [isOpen, fetchStatus, fetchComparison]);

  const handleTriggerRun = async () => {
    setTriggering(true);
    setTriggerMsg('');
    try {
      const res = await fetch(`${AI_API_URL}/trigger-run`, { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        setStatus(data.status);
        setTriggerMsg('⚡ Immediate AI background audit pass executed successfully!');
        fetchComparison();
        setTimeout(() => setTriggerMsg(''), 4000);
      }
    } catch (err) {
      setTriggerMsg('⚠️ Failed to trigger pass: ' + err.message);
    } finally {
      setTriggering(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="ai-modal-overlay" onClick={onClose}>
      <div className="ai-modal-container" onClick={e => e.stopPropagation()}>
        {/* Modal Header */}
        <div className="ai-modal-header">
          <div className="ai-modal-title">
            <span className="ai-pulse-dot" />
            <div>
              <h3>AI Pricing Valuation & Background Audit Model</h3>
              <p>Continuous automated daemon comparing pre-existing historical datasets against active ledger records</p>
            </div>
          </div>
          <button className="ai-modal-close" onClick={onClose} aria-label="Close modal">✕</button>
        </div>

        {/* Live Metrics Grid */}
        <div className="ai-metrics-grid">
          <div className="ai-metric-box">
            <span className="ai-metric-label">BACKGROUND ENGINE</span>
            <div className="ai-metric-val ai-status-running">
              <span className="ai-pulse-mini" /> {status?.status || 'RUNNING'}
            </div>
            <small>Cycle: Every {(status?.intervalMs || 10000) / 1000}s</small>
          </div>

          <div className="ai-metric-box">
            <span className="ai-metric-label">AUDIT PASSES</span>
            <div className="ai-metric-val">{status?.cyclesCompleted ?? '—'}</div>
            <small>Total checks: {status?.totalAuditedRecords ?? 0}</small>
          </div>

          <div className="ai-metric-box">
            <span className="ai-metric-label">LEDGER BATCHES</span>
            <div className="ai-metric-val">{status?.currentActiveBatches ?? '—'}</div>
            <small>Audited in real-time</small>
          </div>

          <div className="ai-metric-box">
            <span className="ai-metric-label">AVERAGE FAIRNESS</span>
            <div className="ai-metric-val text-emerald">
              {status?.avgFairnessScore ? `${status.avgFairnessScore}%` : '98%'}
            </div>
            <small>Based on regional baselines</small>
          </div>

          <div className="ai-metric-box">
            <span className="ai-metric-label">ANOMALY WARNINGS</span>
            <div className={`ai-metric-val ${status?.anomaliesDetected > 0 ? 'text-amber' : 'text-emerald'}`}>
              {status?.anomaliesDetected ?? 0}
            </div>
            <small>Discrepancy flags</small>
          </div>
        </div>

        {/* Action Bar */}
        <div className="ai-action-bar">
          <div className="ai-tabs">
            <button
              className={`ai-tab ${activeTab === 'stream' ? 'active' : ''}`}
              onClick={() => setActiveTab('stream')}
            >
              📡 Live Background Audit Stream
            </button>
            <button
              className={`ai-tab ${activeTab === 'comparison' ? 'active' : ''}`}
              onClick={() => { setActiveTab('comparison'); fetchComparison(); }}
            >
              📊 Old Data vs New Data Comparison
            </button>
          </div>

          <div className="ai-actions-right">
            <button
              className="ai-trigger-btn"
              onClick={handleTriggerRun}
              disabled={triggering}
            >
              {triggering ? '⏳ Auditing…' : '⚡ Run Background Scan Now'}
            </button>
          </div>
        </div>

        {triggerMsg && <div className="ai-alert-banner">{triggerMsg}</div>}

        {/* Tab Content: Live Stream */}
        {activeTab === 'stream' && (
          <div className="ai-stream-view">
            <div className="ai-stream-header">
              <span>REAL-TIME AUDIT LOG (CONTINUOUS BACKGROUND MODEL EVALUATIONS)</span>
              <small>Auto-updating • Showing latest {status?.recentLogs?.length || 0} passes</small>
            </div>

            <div className="ai-logs-container">
              {(!status?.recentLogs || status.recentLogs.length === 0) ? (
                <div className="ai-empty-logs">Initial background evaluation in progress…</div>
              ) : (
                status.recentLogs.map((log) => {
                  const isAnomaly = log.fairnessStatus !== 'fair';
                  return (
                    <div key={log.id} className={`ai-log-row ${isAnomaly ? 'ai-log-anomaly' : 'ai-log-fair'}`}>
                      <div className="ai-log-time">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </div>
                      <div className="ai-log-badge">
                        <span className={`ai-chip ${isAnomaly ? 'chip-warning' : 'chip-success'}`}>
                          {log.fairnessStatus.replace(/_/g, ' ').toUpperCase()}
                        </span>
                      </div>
                      <div className="ai-log-body">
                        <div className="ai-log-topline">
                          <strong>{log.productName}</strong>
                          <code>{log.batchId}</code>
                          <span className="ai-log-farm">🌾 {log.farmer}</span>
                        </div>
                        <div className="ai-log-prices">
                          <span>Set Farmer Price: <b>₹{log.originalFarmerPrice}</b></span>
                          <span className="ai-divider">|</span>
                          <span>Baseline Avg: <b>₹{log.baselineFarmerPrice}</b></span>
                          <span className="ai-divider">|</span>
                          <span>Retail: <b>₹{log.retailPrice}</b></span>
                          <span className="ai-divider">|</span>
                          <span>Farmer Share: <b>{log.farmerSharePct}%</b></span>
                          <span className="ai-divider">|</span>
                          <span className="ai-score-pill">Score: {log.fairnessScore}/100</span>
                        </div>
                        <p className="ai-log-summary">{log.summary}</p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Tab Content: Old Data vs New Data Comparison */}
        {activeTab === 'comparison' && (
          <div className="ai-comparison-view">
            <div className="ai-comparison-header">
              <div>
                <h4>Pre-Existing Historical Baseline (Old Data) vs Active Ledger Batches (New Data)</h4>
                <p>The AI model tracks price distribution divergence across regional multi-season datasets.</p>
              </div>
            </div>

            <div className="ai-table-wrap">
              <table className="ai-comparison-table">
                <thead>
                  <tr>
                    <th>COMMODITY &amp; REGION</th>
                    <th>HISTORICAL (OLD DATA)<br /><small>Avg Farm Price / Band</small></th>
                    <th>TYPICAL FARMER SHARE<br /><small>Old Benchmark</small></th>
                    <th>CURRENT ACTIVE (NEW DATA)<br /><small>Set by Farmer</small></th>
                    <th>CURRENT FARMER SHARE<br /><small>Actual % of Retail</small></th>
                    <th>VARIANCE &amp; STATUS<br /><small>AI Drift Model</small></th>
                  </tr>
                </thead>
                <tbody>
                  {comparison?.commodities?.map((c) => {
                    const hasActive = c.currentLedger.matchingBatchesCount > 0;
                    return (
                      <tr key={c.id} className={hasActive ? 'row-active' : 'row-dormant'}>
                        <td>
                          <b>{c.commodity}</b>
                          <div className="table-sub">{c.region} • <i>{c.unit}</i></div>
                        </td>
                        <td>
                          <div className="price-bold">₹{c.historical.farmerPriceAvg}</div>
                          <small className="table-sub">₹{c.historical.farmerPriceMin} - ₹{c.historical.farmerPriceMax}</small>
                        </td>
                        <td>
                          <span className="badge-share">{c.historical.farmerSharePct}%</span>
                        </td>
                        <td>
                          {hasActive ? (
                            <div>
                              <div className="price-bold text-accent">₹{c.currentLedger.activeFarmerPriceAvg}</div>
                              <small className="table-sub">{c.currentLedger.batchIds.join(', ')}</small>
                            </div>
                          ) : (
                            <span className="table-muted">No active batches</span>
                          )}
                        </td>
                        <td>
                          {hasActive ? (
                            <span className="badge-share-active">{c.currentLedger.activeFarmerSharePct}%</span>
                          ) : (
                            <span className="table-muted">—</span>
                          )}
                        </td>
                        <td>
                          {hasActive ? (
                            <div>
                              <span className={`ai-status-pill pill-${c.variance.status.toLowerCase()}`}>
                                {c.variance.farmerPriceDiff >= 0 ? `+₹${c.variance.farmerPriceDiff}` : `-₹${Math.abs(c.variance.farmerPriceDiff)}`} ({c.variance.variancePct}%)
                              </span>
                              <div className="table-sub-pill">{c.variance.status.replace(/_/g, ' ')}</div>
                            </div>
                          ) : (
                            <span className="ai-status-pill pill-baseline">Baseline Ready</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="ai-modal-footer">
          <small>
            🔒 FarmToFork AI Model runs autonomously in the background • Auditing farmgate integrity, preventing price tampering &amp; empowering farmer transparency.
          </small>
          <button className="ai-btn-secondary" onClick={onClose}>Close Monitor</button>
        </div>
      </div>
    </div>
  );
}
