import React, { useState, useMemo } from 'react';

const COMMODITY_BASELINES = [
  { id: 'mango', name: 'Ratnagiri Alphonso Mangoes', emoji: '🥭', unit: 'dozen', baselineAvg: 550, baselineMin: 450, baselineMax: 650, defaultRetail: 1150 },
  { id: 'apple', name: 'Organic Fuji Apples', emoji: '🍎', unit: 'kg', baselineAvg: 100, baselineMin: 85, baselineMax: 125, defaultRetail: 250 },
  { id: 'milk', name: 'A2 Gir Cow Milk', emoji: '🥛', unit: 'liter', baselineAvg: 52, baselineMin: 48, baselineMax: 62, defaultRetail: 90 },
  { id: 'honey', name: 'Sundarbans Wild Raw Honey', emoji: '🍯', unit: 'kg', baselineAvg: 380, baselineMin: 320, baselineMax: 450, defaultRetail: 650 },
  { id: 'strawberry', name: 'Mahabaleshwar Strawberries', emoji: '🍓', unit: 'box (500g)', baselineAvg: 140, baselineMin: 120, baselineMax: 180, defaultRetail: 280 },
  { id: 'cheese', name: 'Artisanal Goat Cheese', emoji: '🧀', unit: 'wheel (400g)', baselineAvg: 320, baselineMin: 280, baselineMax: 400, defaultRetail: 550 },
  { id: 'orange', name: 'Nagpur Organic Oranges', emoji: '🍊', unit: 'kg', baselineAvg: 48, baselineMin: 40, baselineMax: 60, defaultRetail: 105 },
  { id: 'eggs', name: 'Free-Range Eggs', emoji: '🥚', unit: 'crate (30 pcs)', baselineAvg: 290, baselineMin: 260, baselineMax: 340, defaultRetail: 500 },
  { id: 'tomato', name: 'Heirloom Tomato Mix', emoji: '🍅', unit: 'kg', baselineAvg: 120, baselineMin: 95, baselineMax: 145, defaultRetail: 250 },
];

export default function AIPriceSimulatorModal({ isOpen, onClose, onApplyToForm }) {
  const [selectedId, setSelectedId] = useState('mango');
  const commodity = useMemo(() => COMMODITY_BASELINES.find(c => c.id === selectedId) || COMMODITY_BASELINES[0], [selectedId]);

  const [farmerPrice, setFarmerPrice] = useState(commodity.baselineAvg);
  const [retailPrice, setRetailPrice] = useState(commodity.defaultRetail);

  // When changing commodity, reset sliders to that commodity's defaults
  const handleSelectCommodity = (id) => {
    setSelectedId(id);
    const target = COMMODITY_BASELINES.find(c => c.id === id);
    if (target) {
      setFarmerPrice(target.baselineAvg);
      setRetailPrice(target.defaultRetail);
    }
  };

  // Calculations
  const diffFromBaseline = farmerPrice - commodity.baselineAvg;
  const deviationPct = Math.round((diffFromBaseline / commodity.baselineAvg) * 100);
  const middlemanMargin = Math.max(0, retailPrice - farmerPrice);
  const farmerSharePct = retailPrice > 0 ? Math.round((farmerPrice / retailPrice) * 100) : 0;
  const middlemanSharePct = 100 - farmerSharePct;

  // Fairness Score Calculation
  let score = 95;
  let status = 'fair';
  let verdict = 'Optimal Fair Value: Pricing aligns with historical multi-season benchmarks.';

  if (deviationPct < -22) {
    status = 'underpriced';
    score = Math.max(30, 85 + deviationPct);
    verdict = `⚠️ Distress Sale Alert: Price is ${Math.abs(deviationPct)}% below historical average (₹${commodity.baselineAvg}). Middlemen capture excessive surplus.`;
  } else if (deviationPct > 35) {
    status = 'overpriced';
    score = Math.max(45, 100 - (deviationPct - 30));
    verdict = `Above Regional Norm: Price is ${deviationPct}% above benchmark. Ensure premium grade or GI certification justifies this rate.`;
  } else if (farmerSharePct < 25) {
    status = 'exploitation';
    score = Math.min(58, farmerSharePct * 2);
    verdict = `Middleman Gouging: Farmer receives only ${farmerSharePct}% of consumer retail price. Distributors capture ₹${middlemanMargin}.`;
  }

  const scoreColor = score >= 80 ? '#10b981' : score >= 60 ? '#f59e0b' : '#ef4444';

  if (!isOpen) return null;

  return (
    <div className="fluid-modal-overlay" onClick={onClose}>
      <div className="simulator-modal-card" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="fluid-modal-header">
          <div className="fluid-modal-title-group">
            <span className="modal-kicker">INTERACTIVE ECONOMETRIC ENGINE</span>
            <h3>🔮 AI Price Fairness &amp; Margin Simulator</h3>
            <p>
              Simulate dynamic price variations, assess farmer revenue share vs. middleman extraction, and preview instant AI diagnostic scores.
            </p>
          </div>
          <button className="fluid-modal-close" onClick={onClose}>✕</button>
        </div>

        <div className="simulator-body-grid">
          {/* Left Column: Sliders & Controls */}
          <div className="sim-controls-col">
            <label className="sim-field-label">1. SELECT COMMODITY</label>
            <div className="sim-commodity-chips">
              {COMMODITY_BASELINES.map(c => (
                <button
                  key={c.id}
                  type="button"
                  className={`sim-chip ${selectedId === c.id ? 'active' : ''}`}
                  onClick={() => handleSelectCommodity(c.id)}
                >
                  <span>{c.emoji}</span>
                  <b>{c.name.split(' ')[0]}</b>
                </button>
              ))}
            </div>

            {/* Slider 1: Farmer Farmgate Price */}
            <div className="sim-slider-group">
              <div className="sim-slider-header">
                <div>
                  <span className="sim-slider-name">🧑‍🌾 Proposed Farmgate Price</span>
                  <small>Regional Benchmark: ₹{commodity.baselineAvg} / {commodity.unit}</small>
                </div>
                <div className="sim-slider-val-badge">₹{farmerPrice}</div>
              </div>
              <input
                type="range"
                min={Math.max(10, Math.round(commodity.baselineMin * 0.4))}
                max={Math.round(commodity.baselineMax * 1.8)}
                value={farmerPrice}
                onChange={e => setFarmerPrice(Number(e.target.value))}
                className="sim-range-input farmer-slider"
              />
              <div className="sim-range-ticks">
                <span>Distress (₹{Math.round(commodity.baselineMin * 0.6)})</span>
                <span className="tick-center">Fair Band: ₹{commodity.baselineMin} - ₹{commodity.baselineMax}</span>
                <span>Premium (₹{Math.round(commodity.baselineMax * 1.5)})</span>
              </div>
            </div>

            {/* Slider 2: Retail Market Price */}
            <div className="sim-slider-group">
              <div className="sim-slider-header">
                <div>
                  <span className="sim-slider-name">🛒 Final Consumer Retail Price</span>
                  <small>Shelf price at city supermarkets</small>
                </div>
                <div className="sim-slider-val-badge">₹{retailPrice}</div>
              </div>
              <input
                type="range"
                min={farmerPrice + 10}
                max={Math.max(farmerPrice * 3, commodity.defaultRetail * 2)}
                value={retailPrice}
                onChange={e => setRetailPrice(Number(e.target.value))}
                className="sim-range-input retail-slider"
              />
              <div className="sim-range-ticks">
                <span>Direct ₹{farmerPrice + 20}</span>
                <span>Average ₹{commodity.defaultRetail}</span>
                <span>High ₹{Math.round(commodity.defaultRetail * 1.8)}</span>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="sim-quick-presets">
              <small>Quick Simulation Scenarios:</small>
              <div className="sim-preset-btns">
                <button
                  type="button"
                  onClick={() => {
                    setFarmerPrice(commodity.baselineAvg);
                    setRetailPrice(commodity.defaultRetail);
                  }}
                >
                  ✅ Fair Trade (Optimal)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFarmerPrice(Math.round(commodity.baselineAvg * 0.5));
                    setRetailPrice(commodity.defaultRetail);
                  }}
                >
                  ⚠️ Distress Underpricing
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFarmerPrice(Math.round(commodity.baselineAvg * 0.35));
                    setRetailPrice(Math.round(commodity.defaultRetail * 1.3));
                  }}
                >
                  🚨 Middleman Gouging
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Visual AI Gauge & Results */}
          <div className="sim-results-col">
            {/* Visual Gauge Dial */}
            <div className="sim-gauge-card">
              <span className="sim-gauge-title">AI FAIRNESS SCORE</span>
              <div className="sim-gauge-meter">
                <div
                  className="sim-meter-circle"
                  style={{
                    background: `conic-gradient(${scoreColor} ${score * 3.6}deg, #e2e8f0 0deg)`,
                  }}
                >
                  <div className="sim-meter-inner">
                    <span className="sim-meter-number" style={{ color: scoreColor }}>{score}</span>
                    <small>/ 100</small>
                  </div>
                </div>
              </div>

              <div className={`sim-status-chip sim-status-${status}`}>
                {status === 'fair' && '✓ OPTIMAL FAIR TRADE'}
                {status === 'underpriced' && '⚠️ DISTRESS SALE WARNING'}
                {status === 'overpriced' && 'ℹ️ ABOVE REGIONAL NORM'}
                {status === 'exploitation' && '🚨 MIDDLEMAN EXPLOITATION'}
              </div>

              <p className="sim-verdict-text">{verdict}</p>
            </div>

            {/* Live Margin Split Architecture */}
            <div className="sim-split-card">
              <span className="sim-split-title">SIMULATED REVENUE DISTRIBUTION</span>
              <div className="sim-stacked-bar">
                <div
                  className="sim-bar-farmer"
                  style={{ width: `${farmerSharePct}%` }}
                  title={`Farmer receives ₹${farmerPrice} (${farmerSharePct}%)`}
                />
                <div
                  className="sim-bar-middleman"
                  style={{ width: `${middlemanSharePct}%` }}
                  title={`Middlemen capture ₹${middlemanMargin} (${middlemanSharePct}%)`}
                />
              </div>

              <div className="sim-split-metrics">
                <div className="sim-split-item">
                  <span className="sim-dot farmer" />
                  <div>
                    <b>Farmer Share: {farmerSharePct}%</b>
                    <small>₹{farmerPrice} direct revenue</small>
                  </div>
                </div>
                <div className="sim-split-item">
                  <span className="sim-dot middleman" />
                  <div>
                    <b>Intermediaries: {middlemanSharePct}%</b>
                    <small>₹{middlemanMargin} logistics &amp; retail markup</small>
                  </div>
                </div>
              </div>

              <div className="sim-benchmark-comparison">
                <span>Traditional Supermarket Farmer Share: <b>18%</b></span>
                <span className="sim-comp-delta">
                  {farmerSharePct >= 18 ? `+${farmerSharePct - 18}% better for producer` : `${farmerSharePct - 18}% below standard`}
                </span>
              </div>
            </div>

            {/* Action buttons */}
            <div className="sim-action-row">
              {onApplyToForm && (
                <button
                  type="button"
                  className="primary sim-btn-apply"
                  onClick={() => {
                    onApplyToForm(commodity.name, farmerPrice, retailPrice);
                    onClose();
                  }}
                >
                  Apply ₹{farmerPrice} to New Harvest Entry →
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="fluid-modal-footer">
          <small>
            💡 Connected to Hedonic Statistical Model in <code>server/services/aiPricingModel.js</code>.
          </small>
          <button className="primary-sm" onClick={onClose}>Close Simulator</button>
        </div>
      </div>
    </div>
  );
}
