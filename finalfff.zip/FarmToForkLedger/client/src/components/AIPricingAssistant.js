import React, { useState, useEffect } from 'react';
import { AI_API_URL } from '../config';

export default function AIPricingAssistant({ form, onApplyRecommendedPrice }) {
  const [assessment, setAssessment] = useState(null);
  const [loading, setLoading] = useState(false);

  const farmerPrice = Number(form.farmerPrice) || 0;
  const retailPrice = Number(form.retailPrice) || 0;
  const name = form.name || '';

  useEffect(() => {
    // If name or farmerPrice is missing, clear assessment
    if (!name.trim()) {
      setAssessment(null);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`${AI_API_URL}/evaluate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: form.name,
            category: form.category,
            location: form.location,
            farmerPrice: form.farmerPrice,
            retailPrice: form.retailPrice,
            harvestDate: form.harvestDate,
          }),
        });
        if (res.ok) {
          const data = await res.json();
          setAssessment(data);
        }
      } catch (err) {
        console.warn('AI evaluation error:', err);
      } finally {
        setLoading(false);
      }
    }, 280);

    return () => clearTimeout(timer);
  }, [form.name, form.category, form.location, form.farmerPrice, form.retailPrice, form.harvestDate]);

  if (!name.trim()) return null;

  const comp = assessment?.pricingComparison;
  const base = assessment?.historicalBaseline;
  const status = comp?.fairnessStatus || 'fair';

  const isUnderpriced = status === 'underpriced_warning';
  const isOverpriced = status === 'overpriced_warning';
  const isMarginIssue = status === 'margin_exploitation';
  const isFair = status === 'fair';

  return (
    <div className={`ai-pricing-assistant ${isUnderpriced ? 'assistant-warning' : isMarginIssue ? 'assistant-danger' : 'assistant-good'}`}>
      <div className="ai-assistant-header">
        <div className="ai-assistant-title">
          <span className="ai-assistant-icon">🤖</span>
          <div>
            <b>AI Fair Pricing Intelligence Model</b>
            <span className="ai-assistant-sub">Audited against pre-existing regional historical datasets</span>
          </div>
        </div>

        {comp && (
          <div className="ai-fairness-meter">
            <span className="ai-meter-label">FAIRNESS SCORE</span>
            <span className={`ai-meter-score ${comp.fairnessScore >= 80 ? 'score-green' : comp.fairnessScore >= 60 ? 'score-yellow' : 'score-red'}`}>
              {comp.fairnessScore}/100
            </span>
          </div>
        )}
      </div>

      {loading && <div className="ai-assistant-loading">⟳ AI comparing historical market data…</div>}

      {assessment && (
        <div className="ai-assistant-body">
          {/* Comparison Stats Row */}
          <div className="ai-stats-row">
            <div className="ai-stat-card">
              <span className="ai-stat-label">ORIGINAL FARMER PRICE</span>
              <span className="ai-stat-val">₹{farmerPrice}</span>
              <small>{farmerPrice > 0 ? 'Declared by you' : 'Please enter price'}</small>
            </div>

            <div className="ai-stat-card">
              <span className="ai-stat-label">HISTORICAL BASELINE (OLD DATA)</span>
              <span className="ai-stat-val text-accent">₹{base?.avgFarmerPrice ?? '—'}</span>
              <small>Range: ₹{base?.minFarmerPrice} - ₹{base?.maxFarmerPrice}</small>
            </div>

            <div className="ai-stat-card">
              <span className="ai-stat-label">PRICE VARIANCE</span>
              <span className={`ai-stat-val ${(comp?.deviationPct ?? 0) < -15 ? 'text-amber' : (comp?.deviationPct ?? 0) > 25 ? 'text-amber' : 'text-emerald'}`}>
                {(comp?.deviationPct ?? 0) >= 0 ? `+${comp?.deviationPct}%` : `${comp?.deviationPct}%`}
              </span>
              <small>{isFair ? 'Balanced market rate' : isUnderpriced ? 'Below typical baseline' : 'Above typical baseline'}</small>
            </div>

            <div className="ai-stat-card">
              <span className="ai-stat-label">FARMER SHARE OF RETAIL</span>
              <span className="ai-stat-val text-emerald">
                {comp?.actualFarmerSharePct ? `${comp.actualFarmerSharePct}%` : '—'}
              </span>
              <small>vs 18% conventional avg</small>
            </div>
          </div>

          {/* AI Verdict Box */}
          <div className="ai-verdict-box">
            <div className="ai-verdict-badge">
              {isFair && <span className="tag-fair">✓ OPTIMAL &amp; FAIR PRICING</span>}
              {isUnderpriced && <span className="tag-warning">⚠️ UNDERPRICING RISK DETECTED</span>}
              {isOverpriced && <span className="tag-notice">ℹ️ ABOVE HISTORICAL BENCHMARK</span>}
              {isMarginIssue && <span className="tag-danger">⚠️ EXCESSIVE MIDDLEMAN SPREAD</span>}
            </div>
            <p className="ai-verdict-text">{assessment.farmerVerdict}</p>

            {/* Quick action to adopt recommended baseline price */}
            {base && isUnderpriced && onApplyRecommendedPrice && (
              <button
                type="button"
                className="ai-apply-price-btn"
                onClick={() => onApplyRecommendedPrice(base.avgFarmerPrice)}
              >
                ✨ Apply AI Recommended Fair Price: ₹{base.avgFarmerPrice}
              </button>
            )}
          </div>

          {/* Commodity reference footer */}
          <div className="ai-ref-footer">
            <span>📍 Matched Baseline: <b>{assessment.commodityName}</b> ({base?.region})</span>
            <span>📊 {base?.observationsCount} Historical market observations in dataset</span>
          </div>
        </div>
      )}
    </div>
  );
}
