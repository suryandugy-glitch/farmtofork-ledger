import React, { useState } from 'react';

const RECENT_BLOCKS = [
  {
    height: 849219,
    hash: '0xa3f5c7d8e2b1f94c9c2e0b7a8d4e1f3c2a5b7d9e',
    prevHash: '0x9b4e1a7c3d2f8e0b6a5d4c2e1f9a8b7c3d2e1f0a',
    timestamp: '2026-09-20T17:45:10Z',
    producer: 'Anita Sharma (Green Valley Farm)',
    commodity: 'Organic Fuji Apples (Batch GVF-APPLE-016)',
    farmgatePrice: '₹100 / kg',
    txCount: 4,
    status: 'Confirmed ✅',
    validator: 'USDA Node #03 (Delhi Peer)',
    merkleRoot: '0x7e4a9b2c1d8f3e5a0b6c9d2e1f4a7b8c3d0e2f1a',
    geoCoordinates: '31.1048° N, 77.1734° E (Shimla)',
  },
  {
    height: 849218,
    hash: '0xd4a8f9c1e3b2718a5e016f4c8b2d0e7a9b1c3d5f',
    prevHash: '0x8a7b6c5d4e3f2a1b0c9d8e7f6a5b4c3d2e1f0a9b',
    timestamp: '2026-09-20T16:30:22Z',
    producer: 'Sanjay Sawant (Konkan Orchard Groves)',
    commodity: 'Ratnagiri Alphonso Mangoes (Batch KOG-MANGO-088)',
    farmgatePrice: '₹550 / dozen',
    txCount: 5,
    status: 'Confirmed ✅',
    validator: 'AgriConsensus Node #01 (Mumbai Peer)',
    merkleRoot: '0x4c8b2d0e7a9b1c3d5f0e2b1f94c9c2e0b7a8d4e1',
    geoCoordinates: '16.9902° N, 73.3120° E (Ratnagiri)',
  },
  {
    height: 849217,
    hash: '0xe5b9a7c2d4f3819b6f127a5d9c3e1f8a0b2d4e6c',
    prevHash: '0x7f6e5d4c3b2a10f9e8d7c6b5a4f3e2d1c0b9a8f7',
    timestamp: '2026-09-20T15:10:45Z',
    producer: 'Balwinder Singh (Vedic Roots Dairy Farm)',
    commodity: 'A2 Gir Cow Farm Fresh Milk (Batch VRD-MILK-102)',
    farmgatePrice: '₹52 / liter',
    txCount: 3,
    status: 'Confirmed ✅',
    validator: 'DairyIntegrity Node #07 (Karnal Peer)',
    merkleRoot: '0x1f8a0b2d4e6c7a5d9c3e1f94c9c2e0b7a8d4e1f3',
    geoCoordinates: '29.6857° N, 76.9905° E (Karnal)',
  },
  {
    height: 849216,
    hash: '0xf6c1b8d3e5a4920c7a238b6e0d4f2a9c1b3d5e7f',
    prevHash: '0x6e5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e7d',
    timestamp: '2026-09-20T14:02:18Z',
    producer: 'Subrata Mandal (Sundarbans Beekeepers Coop)',
    commodity: 'Pure Sundarbans Wild Raw Honey (Batch SFB-HONEY-019)',
    farmgatePrice: '₹380 / kg',
    txCount: 4,
    status: 'Confirmed ✅',
    validator: 'BioTrace Node #02 (Kolkata Peer)',
    merkleRoot: '0x8b6e0d4f2a9c1b3d5e7f0b2d4e6c7a5d9c3e1f8a',
    geoCoordinates: '22.1457° N, 88.7562° E (Sundarbans)',
  },
  {
    height: 849215,
    hash: '0x17d2c9e4f6b5031d8b349c7f1e5a3b0d2c4e6f8a',
    prevHash: '0x5d4c3b2a1f0e9d8c7b6a5f4e3d2c1b0a9f8e7d6c',
    timestamp: '2026-09-20T12:20:00Z',
    producer: 'Prashant Shinde (Highland Berry Orchards)',
    commodity: 'Mahabaleshwar Organic Strawberries (Batch HBO-BERRY-063)',
    farmgatePrice: '₹140 / box',
    txCount: 4,
    status: 'Confirmed ✅',
    validator: 'ColdChain Node #04 (Pune Peer)',
    merkleRoot: '0x9c7f1e5a3b0d2c4e6f8a0b2d4e6c7a5d9c3e1f8a',
    geoCoordinates: '17.9237° N, 73.6586° E (Mahabaleshwar)',
  },
];

export default function BlockExplorerModal({ isOpen, onClose }) {
  const [selectedBlock, setSelectedBlock] = useState(RECENT_BLOCKS[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedHash, setCopiedHash] = useState('');

  if (!isOpen) return null;

  const filteredBlocks = RECENT_BLOCKS.filter(b => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      b.hash.toLowerCase().includes(q) ||
      b.commodity.toLowerCase().includes(q) ||
      b.producer.toLowerCase().includes(q) ||
      String(b.height).includes(q)
    );
  });

  const copyHash = (hash) => {
    navigator.clipboard?.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(''), 2000);
  };

  return (
    <div className="fluid-modal-overlay" onClick={onClose}>
      <div className="explorer-modal-card" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="fluid-modal-header">
          <div className="fluid-modal-title-group">
            <span className="modal-kicker">DISTRIBUTED LEDGER CONSENSUS</span>
            <h3>⛓️ FarmToFork Decentralized Block Explorer</h3>
            <p>
              Inspect cryptographic SHA-256 blocks, Merkle provenance proofs, multi-party validator signatures, and immutable price locks.
            </p>
          </div>
          <button className="fluid-modal-close" onClick={onClose}>✕</button>
        </div>

        {/* Network Metrics Bar */}
        <div className="explorer-network-bar">
          <div className="network-stat">
            <span className="net-label">LATEST BLOCK</span>
            <b>#{RECENT_BLOCKS[0].height}</b>
          </div>
          <div className="network-stat">
            <span className="net-label">CONSENSUS</span>
            <b>Proof-of-Provenance (PoP)</b>
          </div>
          <div className="network-stat">
            <span className="net-label">AVG FINALITY</span>
            <b>1.2 Seconds</b>
          </div>
          <div className="network-stat">
            <span className="net-label">VALIDATOR NODES</span>
            <b>5 Active Cluster Peers</b>
          </div>
          <div className="network-stat">
            <span className="net-label">BYZANTINE INTEGRITY</span>
            <b className="text-emerald">100% Tamper-Proof</b>
          </div>
        </div>

        {/* Search Bar */}
        <div className="explorer-search-box">
          <input
            type="text"
            placeholder="Search by block #, SHA-256 hash, commodity, or farm..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>

        {/* Split View: Block List & Block Inspector */}
        <div className="explorer-content-grid">
          {/* Left: Chain List */}
          <div className="explorer-blocks-col">
            <span className="col-heading">RECENT VERIFIED BLOCKS</span>
            <div className="blocks-scroll-list">
              {filteredBlocks.map(block => (
                <div
                  key={block.height}
                  className={`block-list-item ${selectedBlock.height === block.height ? 'selected' : ''}`}
                  onClick={() => setSelectedBlock(block)}
                >
                  <div className="block-item-header">
                    <span className="block-height-pill">#{block.height}</span>
                    <span className="block-status-tag">{block.status}</span>
                  </div>
                  <b className="block-commodity-name">{block.commodity}</b>
                  <div className="block-producer-meta">
                    <span>{block.producer}</span>
                  </div>
                  <div className="block-hash-preview">
                    <code>{block.hash.slice(0, 16)}...{block.hash.slice(-8)}</code>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Selected Block Deep Inspector */}
          <div className="explorer-detail-col">
            <div className="block-inspector-card">
              <div className="inspector-top-row">
                <div>
                  <span className="inspector-label">BLOCK INSPECTION</span>
                  <h4>Block #{selectedBlock.height}</h4>
                </div>
                <button
                  type="button"
                  className="btn-copy-hash"
                  onClick={() => copyHash(selectedBlock.hash)}
                >
                  {copiedHash === selectedBlock.hash ? '✓ Copied Hash' : '📋 Copy SHA-256 Hash'}
                </button>
              </div>

              {/* Table of Ledger Details */}
              <table className="explorer-detail-table">
                <tbody>
                  <tr>
                    <td>Block Hash</td>
                    <td><code className="code-break">{selectedBlock.hash}</code></td>
                  </tr>
                  <tr>
                    <td>Previous Hash</td>
                    <td><code className="code-break">{selectedBlock.prevHash}</code></td>
                  </tr>
                  <tr>
                    <td>Merkle Root</td>
                    <td><code className="code-break">{selectedBlock.merkleRoot}</code></td>
                  </tr>
                  <tr>
                    <td>Producer &amp; Origin</td>
                    <td><b>{selectedBlock.producer}</b></td>
                  </tr>
                  <tr>
                    <td>GPS Geo-Fence</td>
                    <td>📍 {selectedBlock.geoCoordinates}</td>
                  </tr>
                  <tr>
                    <td>Commodity Lot</td>
                    <td>{selectedBlock.commodity}</td>
                  </tr>
                  <tr>
                    <td>Immutable Farmgate Price</td>
                    <td><b className="text-emerald">{selectedBlock.farmgatePrice}</b> <small>(Permanently sealed)</small></td>
                  </tr>
                  <tr>
                    <td>Consensus Validator</td>
                    <td>🏛️ {selectedBlock.validator}</td>
                  </tr>
                  <tr>
                    <td>Timestamp</td>
                    <td>🕐 {new Date(selectedBlock.timestamp).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'medium' })}</td>
                  </tr>
                </tbody>
              </table>

              {/* Cryptographic Seal Banner */}
              <div className="cryptographic-seal-box">
                <span className="seal-icon">🛡️</span>
                <div>
                  <b>Cryptographic Proof of Provenance Sealed</b>
                  <p>
                    This transaction was validated across distributed peers and can never be modified by downstream aggregators or retailers.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="fluid-modal-footer">
          <small>
            ⚡ Powered by SHA-256 Merkle Ledger. Zero central authority pricing tampering.
          </small>
          <button className="primary-sm" onClick={onClose}>Done</button>
        </div>
      </div>
    </div>
  );
}
