import React, { useRef, useState } from 'react';
import ProvenanceCertificateModal from './ProvenanceCertificateModal';

import { API_URL as API } from '../config';

/* Map product name/category keywords to demo asset images */
const getProductImage = (product) => {
  if (!product) return null;
  // Prefer the farmer-uploaded image stored on the server
  if (product.productImage) return product.productImage;
  // Fall back to demo assets based on name keywords
  const name = (product.name || '').toLowerCase();
  if (name.includes('mango') || name.includes('alphonso')) return '/assets/mango.jpg';
  if (name.includes('milk')  || name.includes('dairy') || name.includes('gir')) return '/assets/milk.jpg';
  if (name.includes('honey')) return '/assets/honey.jpg';
  if (name.includes('strawberr') || name.includes('berry')) return '/assets/strawberry.jpg';
  if (name.includes('cheese') || name.includes('chevre')) return '/assets/cheese.jpg';
  if (name.includes('orange') || name.includes('citrus') || name.includes('mandarin')) return '/assets/orange.jpg';
  if (name.includes('apple') || name.includes('fuji') || name.includes('gala')) return '/assets/apple.jpg';
  if (name.includes('egg')   || name.includes('chicken') || name.includes('poultry')) return '/assets/eggs.jpg';
  if (name.includes('tomato')) return '/assets/tomato.jpg';
  return null;
};

/* Build a full supply chain timeline from all available data */
const buildSupplyChainSteps = (product) => {
  const steps = [];

  // Step 1: Farmer (from audit log "Draft created" / "Submitted to USDA")
  const farmerAudit = (product.auditLog || []).find(a => a.action === 'Draft created' || a.action === 'Submitted to USDA');
  const farmerVerification = (product.verifications || []).find(v =>
    v.actor && (v.actor.toLowerCase().includes('farm') || v.actor.toLowerCase().includes('farmer') || v.actor.toLowerCase().includes('producer'))
  );
  steps.push({
    stage: '🧑‍🌾 Farmer',
    actor: farmerVerification?.actor || farmerAudit?.actor || product.farm || 'Farmer',
    note: farmerVerification?.note || farmerAudit?.note || 'Harvest record created.',
    timestamp: farmerVerification?.timestamp || farmerAudit?.timestamp || null,
    status: 'done',
  });

  // Step 2: USDA Review
  const usdaAudit = (product.auditLog || []).find(a =>
    a.action === 'Approved' || a.action === 'Correction requested' || a.actor?.toLowerCase().includes('usda')
  );
  const usdaVerification = (product.verifications || []).find(v => v.actor?.toLowerCase().includes('usda'));
  const usdaStatus = product.status === 'usda-approved' || product.status === 'in-transit' || product.status === 'fully-verified'
    ? 'done'
    : product.status === 'usda-correction-required' ? 'correction' : 'pending';
  steps.push({
    stage: '🏛️ USDA Review',
    actor: usdaVerification?.actor || usdaAudit?.actor || 'USDA Food Safety Desk',
    note: usdaVerification?.note || usdaAudit?.note ||
      (usdaStatus === 'pending' ? 'Awaiting USDA review.' : ''),
    timestamp: usdaVerification?.timestamp || usdaAudit?.timestamp || null,
    status: usdaStatus,
  });

  // Step 3: Aggregator
  const aggVerification = (product.verifications || []).find(v =>
    v.actor && (v.actor.toLowerCase().includes('aggregator') || v.actor.toLowerCase().includes('hub') ||
                v.actor.toLowerCase().includes('fresh') || v.actor.toLowerCase().includes('natura'))
  );
  const aggAudit = (product.auditLog || []).find(a => a.actor?.toLowerCase().includes('aggregator'));
  const aggDone = !!aggVerification || !!aggAudit || ['in-transit','fully-verified'].includes(product.status);
  const aggPending = !aggDone && product.nextVerifier === 'aggregator';
  steps.push({
    stage: '📦 Aggregator',
    actor: aggVerification?.actor || aggAudit?.actor || 'Aggregator partner',
    note: aggVerification?.note || aggAudit?.note || (aggPending ? 'Awaiting aggregator handoff.' : aggDone ? 'Aggregator handoff verified.' : 'Not yet reached.'),
    timestamp: aggVerification?.timestamp || aggAudit?.timestamp || null,
    status: aggDone ? 'done' : aggPending ? 'pending' : 'waiting',
  });

  // Step 4: Retailer
  const retVerification = (product.verifications || []).find(v =>
    v.actor && (v.actor.toLowerCase().includes('retail') || v.actor.toLowerCase().includes('basket') ||
                v.actor.toLowerCase().includes('store') || v.actor.toLowerCase().includes('shop'))
  );
  const retAudit = (product.auditLog || []).find(a => a.actor?.toLowerCase().includes('retailer'));
  const retDone = !!retVerification || !!retAudit || product.status === 'fully-verified';
  const retPending = !retDone && product.nextVerifier === 'retailer';
  steps.push({
    stage: '🏪 Retailer',
    actor: retVerification?.actor || retAudit?.actor || 'Retail partner',
    note: retVerification?.note || retAudit?.note || (retPending ? 'Awaiting retailer handoff.' : retDone ? 'Retail receipt verified.' : 'Not yet reached.'),
    timestamp: retVerification?.timestamp || retAudit?.timestamp || null,
    status: retDone ? 'done' : retPending ? 'pending' : 'waiting',
  });

  // Step 5: Consumer (you)
  steps.push({
    stage: '🛒 Consumer (You)',
    actor: 'End Consumer',
    note: product.status === 'fully-verified'
      ? 'Full farm-to-fork chain verified ✅ — you are viewing authenticated product data.'
      : 'Product is en route through the supply chain.',
    timestamp: null,
    status: product.status === 'fully-verified' ? 'done' : 'waiting',
  });

  return steps;
};

const ConsumerQRLookup = ({ initialCode = '' }) => {
  const canvasRef  = useRef(null);
  const [manualCode, setManualCode] = useState(initialCode || '');
  const [product,    setProduct]    = useState(null);
  const [loading,    setLoading]    = useState(false);
  const [error,      setError]      = useState('');
  const [fileName,   setFileName]   = useState('');
  const [showHistorical, setShowHistorical] = useState(false);
  const [showCert,       setShowCert]       = useState(false);

  React.useEffect(() => {
    if (initialCode) {
      setManualCode(initialCode);
      lookup(initialCode);
    }
  }, [initialCode]);

  const lookup = async (code) => {
    if (!code || !code.trim()) { setError('Please enter or scan a QR code.'); return; }
    setLoading(true);
    setError('');
    setProduct(null);
    try {
      const res  = await fetch(`${API}/${code.trim()}`, { headers: { 'x-user-role': 'consumer' } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || 'Product not found.');
      setProduct(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setFileName(file.name);
    setError('');

    try {
      const jsQR   = (await import('jsqr')).default;
      const bitmap = await createImageBitmap(file);
      const canvas = canvasRef.current;
      const ctx    = canvas.getContext('2d');
      canvas.width  = bitmap.width;
      canvas.height = bitmap.height;
      ctx.drawImage(bitmap, 0, 0);
      const imageData = ctx.getImageData(0, 0, bitmap.width, bitmap.height);
      const code      = jsQR(imageData.data, bitmap.width, bitmap.height);
      if (code) {
        setManualCode(code.data);
        lookup(code.data);
      } else {
        setError('No QR code found in the uploaded image. Try typing the code manually below.');
      }
    } catch (err) {
      setError('Could not process image: ' + err.message);
    }
    e.target.value = '';
  };

  const statusColor = (s) => {
    const map = {
      draft: '#f59e0b',
      'awaiting-usda': '#3b82f6',
      'usda-approved': '#10b981',
      'usda-correction-required': '#ef4444',
      'in-transit': '#8b5cf6',
      'fully-verified': '#059669',
    };
    return map[s] || '#6b7280';
  };

  const productImage = product ? getProductImage(product) : null;
  const supplyChain  = product ? buildSupplyChainSteps(product) : [];

  return (
    <div className="consumer-qr-panel">
      <canvas ref={canvasRef} style={{ display: 'none' }} />

      {/* ── Header ── */}
      <div className="consumer-qr-header">
        <p className="section-label">CONSUMER TRANSPARENCY PORTAL</p>
        <h2>🔍 Scan or Upload Your Product QR Code</h2>
        <span>
          Upload the QR code image from your product packaging or type the batch code
          to get full traceability data — farm to your fork.
        </span>
      </div>

      {/* ── Inputs ── */}
      <div className="consumer-qr-inputs">
        {/* Upload from gallery */}
        <label className="upload-box-consumer">
          <input type="file" accept="image/*" onChange={handleUpload} style={{ display: 'none' }} />
          <span className="upload-icon">📁</span>
          <b>Upload QR Image</b>
          <small>{fileName ? `✅ ${fileName}` : 'Choose QR from files'}</small>
        </label>

        {/* Camera capture */}
        <label className="upload-box-consumer upload-box-consumer-camera">
          <input
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleUpload}
            style={{ display: 'none' }}
          />
          <span className="upload-icon">📷</span>
          <b>Scan with Camera</b>
          <small>Take photo of QR code</small>
        </label>

        <div className="manual-input-group">
          <p>Or enter the batch code manually:</p>
          <div className="manual-row">
            <input
              value={manualCode}
              onChange={e => setManualCode(e.target.value)}
              placeholder="e.g. FTF-001-APPLE-20260919"
              onKeyDown={e => e.key === 'Enter' && lookup(manualCode)}
            />
            <button className="primary" onClick={() => lookup(manualCode)} disabled={loading}>
              {loading ? 'Looking up…' : 'Look Up'}
            </button>
          </div>
          <div className="demo-codes">
            <small>Demo batches: </small>
            {[
              { code: 'FTF-001-APPLE-20260919', label: '🍎 Apples' },
              { code: 'FTF-002-EGGS-20260919', label: '🥚 Eggs' },
              { code: 'FTF-003-TOMATO-20260919', label: '🍅 Tomatoes' },
              { code: 'FTF-004-MANGO-20260920', label: '🥭 Alphonso Mangoes' },
              { code: 'FTF-005-MILK-20260920', label: '🥛 A2 Cow Milk' },
              { code: 'FTF-006-HONEY-20260920', label: '🍯 Wild Honey' },
              { code: 'FTF-007-STRAWBERRY-20260920', label: '🍓 Strawberries' },
              { code: 'FTF-008-CHEESE-20260920', label: '🧀 Goat Cheese' },
              { code: 'FTF-009-ORANGE-20260920', label: '🍊 Nagpur Oranges' },
            ].map(({ code, label }) => (
              <button key={code} className="code-chip" onClick={() => { setManualCode(code); lookup(code); }} title={code}>
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {error && <div className="alert-error">⚠️ {error}</div>}

      {/* ── Product Result ── */}
      {product && (
        <div className="product-full-detail">

          {/* Hero row: image + name + badges */}
          <div className="product-hero-row">
            {productImage ? (
              <img
                src={productImage}
                alt={product.name}
                className="consumer-product-image"
              />
            ) : (
              <span className="product-big-emoji">{product.emoji}</span>
            )}
            <div style={{ flex: 1 }}>
              <h2>{product.emoji} {product.name}</h2>
              <div className="product-badges">
                <span className="badge-farm">🌾 {product.farm}</span>
                <span className="badge-loc">📍 {product.location}</span>
                <span className="badge-date">📅 Harvested {product.harvestDate}</span>
                <span className="badge-status" style={{ background: statusColor(product.status) }}>
                  {(product.status || 'in-transit').replace(/-/g, ' ').toUpperCase()}
                </span>
              </div>
              <div className="product-certs">
                {(product.certifications || []).map((c, i) => <span key={i} className="cert-tag">✓ {c}</span>)}
              </div>
              <div className="product-cert-btn-row">
                <button
                  type="button"
                  className="btn-open-cert"
                  onClick={() => setShowCert(true)}
                  title="Generate Official Blockchain Provenance Certificate"
                >
                  📜 Official Provenance &amp; Price Certificate (Print / PDF) →
                </button>
              </div>
            </div>
          </div>

          {/* ════════════ ORIGINAL PRICE SPOTLIGHT & AI AUDIT CARD ════════════ */}
          <div className="consumer-original-price-card">
            <div className="cop-badge-row">
              <span className="cop-tag">🌾 ORIGINAL FARMGATE PRICE SPOTLIGHT</span>
              <span className="cop-ai-seal">🤖 AI Model Audited • Authentic &amp; Verified</span>
            </div>

            <div className="cop-main-row">
              <div className="cop-col cop-farmer">
                <span className="cop-label">ORIGINAL PRICE SET BY FARMER</span>
                <div className="cop-val">₹{product.farmerPrice ?? 0} <small>/ unit</small></div>
                <p className="cop-sub">Direct farmgate revenue received by {product.farm || 'Farmer'}</p>
              </div>

              <div className="cop-arrow">➔</div>

              <div className="cop-col cop-middle">
                <span className="cop-label">SUPPLY CHAIN &amp; LOGISTICS</span>
                <div className="cop-val cop-val-middle">
                  +₹{Math.max(0, (Number(product.retailPrice) || 0) - (Number(product.farmerPrice) || 0))}
                </div>
                <p className="cop-sub">
                  Aggregator cold-chain (+₹{product.aggregatorMargin ?? Math.round(((Number(product.retailPrice) || 0) - (Number(product.farmerPrice) || 0)) * 0.4)}) + Retailer (+₹{product.retailerMargin ?? Math.round(((Number(product.retailPrice) || 0) - (Number(product.farmerPrice) || 0)) * 0.6)})
                </p>
              </div>

              <div className="cop-arrow">➔</div>

              <div className="cop-col cop-retail">
                <span className="cop-label">FINAL PRICE YOU PAY (RETAIL)</span>
                <div className="cop-val cop-val-retail">₹{product.retailPrice ?? 0}</div>
                <p className="cop-sub">Consumer checkout price</p>
              </div>
            </div>

            {/* Distribution split bar */}
            <div className="cop-distribution-bar">
              <div
                className="cop-bar-segment segment-farmer"
                style={{ width: `${Math.min(100, Math.max(18, ((product.farmerPrice || 1) / (product.retailPrice || 1)) * 100))}%` }}
                title={`Farmer Share: ${((product.farmerPrice || 0) / (product.retailPrice || 1) * 100).toFixed(0)}%`}
              >
                🧑‍🌾 Farmer Share: {((product.farmerPrice || 0) / (product.retailPrice || 1) * 100).toFixed(0)}%
              </div>
              <div
                className="cop-bar-segment segment-middleman"
                style={{ width: `${Math.max(15, 100 - ((product.farmerPrice || 0) / (product.retailPrice || 1)) * 100)}%` }}
                title="Logistics & Retail Markups"
              >
                📦 Supply Chain: {(100 - ((product.farmerPrice || 0) / (product.retailPrice || 1)) * 100).toFixed(0)}%
              </div>
            </div>

            <div className="cop-impact-note">
              <strong>💚 Direct Ethical Impact: </strong>
              <span>
                In typical industrial grocery supply chains, farmers receive only <b>15% - 20%</b>. In this transparent batch,
                the cultivator receives <b>{((product.farmerPrice || 0) / (product.retailPrice || 1) * 100).toFixed(0)}%</b> of what you pay!
              </span>
            </div>

            {/* AI Pricing Verification details */}
            {product.aiAssessment && (
              <div className="cop-ai-audit-section">
                <div className="cop-ai-header">
                  <div className="cop-ai-title">
                    <span className="cop-ai-icon">🛡️</span>
                    <div>
                      <b>AI Fair Market Valuation Audit</b>
                      <span>Continuous background model compared against historical regional market datasets</span>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="cop-ai-toggle-btn"
                    onClick={() => setShowHistorical(!showHistorical)}
                  >
                    {showHistorical ? 'Hide Historical Baseline Data ▲' : 'Compare with Historical Data (Old Data) ▼'}
                  </button>
                </div>

                <p className="cop-ai-verdict">
                  {product.aiAssessment.consumerTransparencyVerdict || product.aiAssessment.farmerVerdict}
                </p>

                {showHistorical && product.aiAssessment.historicalBaseline && (
                  <div className="cop-historical-drawer">
                    <div className="cop-hist-grid">
                      <div className="cop-hist-item">
                        <span>Historical Regional Farmgate Avg:</span>
                        <b>₹{product.aiAssessment.historicalBaseline.avgFarmerPrice} / {product.aiAssessment.historicalBaseline.unit}</b>
                      </div>
                      <div className="cop-hist-item">
                        <span>Historical Fair Price Band:</span>
                        <b>₹{product.aiAssessment.historicalBaseline.minFarmerPrice} - ₹{product.aiAssessment.historicalBaseline.maxFarmerPrice}</b>
                      </div>
                      <div className="cop-hist-item">
                        <span>Historical Average Retail:</span>
                        <b>₹{product.aiAssessment.historicalBaseline.avgRetailPrice}</b>
                      </div>
                      <div className="cop-hist-item">
                        <span>Historical Observations in Dataset:</span>
                        <b>{product.aiAssessment.historicalBaseline.observationsCount} verified records</b>
                      </div>
                    </div>
                    <small className="cop-hist-note">
                      🔍 AI Diagnosis: Original price set by farmer (₹{product.farmerPrice}) is{' '}
                      {product.aiAssessment.pricingComparison.priceDifference >= 0
                        ? `+₹${product.aiAssessment.pricingComparison.priceDifference} (+${product.aiAssessment.pricingComparison.deviationPct}%) within normal seasonal market variance.`
                        : `-₹${Math.abs(product.aiAssessment.pricingComparison.priceDifference)} (${product.aiAssessment.pricingComparison.deviationPct}%) vs historical regional benchmark.`}
                    </small>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Batch info + Price breakdown */}
          <div className="detail-grid">
            <div className="detail-section">
              <h3>📋 Batch Information</h3>
              <table className="info-table">
                <tbody>
                  <tr><td>Batch ID</td><td><code>{product.batchId}</code></td></tr>
                  <tr><td>QR Code</td><td><code>{product.qrCode}</code></td></tr>
                  <tr><td>Category</td><td>{product.category === 'animal' ? '🐄 Animal Product' : '🌿 Plant-based'}</td></tr>
                  <tr><td>Blockchain Hash</td><td><code style={{fontSize:'11px'}}>{product.blockchainHash}</code></td></tr>
                  <tr><td>Next Verifier</td><td>{product.nextVerifier ? `⏳ Awaiting ${product.nextVerifier}` : '✅ Fully Verified'}</td></tr>
                </tbody>
              </table>
            </div>

            <div className="detail-section">
              <h3>💰 Full Price Breakdown</h3>
              <table className="price-table">
                <thead>
                  <tr><th>Stage</th><th>Amount (₹)</th></tr>
                </thead>
                <tbody>
                  <tr className="price-farmer"><td>🧑‍🌾 Farmer Price</td><td>₹{product.farmerPrice ?? 0}</td></tr>
                  <tr><td>📦 Aggregator Margin</td><td>+₹{product.aggregatorMargin ?? 0}</td></tr>
                  <tr><td>🏪 Retailer Margin</td><td>+₹{product.retailerMargin ?? 0}</td></tr>
                  <tr className="price-retail"><td>🛒 You Pay (Retail)</td><td>₹{product.retailPrice ?? 0}</td></tr>
                  <tr className="price-share">
                    <td>Farmer's share</td>
                    <td>
                      {product.farmerPrice && product.retailPrice
                        ? `${(product.farmerPrice / product.retailPrice * 100).toFixed(0)}%`
                        : '—'}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* ── Full Supply Chain Timeline ── */}
          <div className="detail-section supply-chain-section">
            <h3>🔗 Full Supply Chain Journey</h3>
            <p className="supply-chain-sub">Every step your product took from the farm to you:</p>
            <div className="supply-chain-timeline">
              {supplyChain.map((step, i) => (
                <div key={i} className={`sc-step sc-step-${step.status}`}>
                  <div className="sc-connector" />
                  <div className="sc-dot-wrap">
                    <div className={`sc-dot sc-dot-${step.status}`}>
                      {step.status === 'done' ? '✓' : step.status === 'pending' ? '⏳' : '○'}
                    </div>
                  </div>
                  <div className="sc-content">
                    <b className="sc-stage">{step.stage}</b>
                    <span className="sc-actor">{step.actor}</span>
                    <p className="sc-note">{step.note}</p>
                    {step.timestamp && (
                      <small className="sc-time">
                        🕐 {new Date(step.timestamp).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
                      </small>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Verification Chain */}
          <div className="detail-section">
            <h3>✅ Verification Chain</h3>
            {(product.verifications || []).length === 0 ? (
              <p style={{ color: '#9ca3af', fontStyle: 'italic' }}>No verifications recorded yet.</p>
            ) : (
              <div className="audit-timeline">
                {(product.verifications || []).map((v, i) => (
                  <div key={i} className="timeline-item verification">
                    <div className="timeline-dot verified" />
                    <div className="timeline-content">
                      <b>✅ {v.actor}</b>
                      <p>{v.note}</p>
                      <small>{v.timestamp ? new Date(v.timestamp).toLocaleString() : ''}</small>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Full Audit Log */}
          <div className="detail-section">
            <h3>📜 Complete Audit Log</h3>
            {(product.auditLog || []).length === 0 ? (
              <p style={{ color: '#9ca3af', fontStyle: 'italic' }}>No audit entries yet.</p>
            ) : (
              <div className="audit-timeline">
                {(product.auditLog || []).map((a, i) => (
                  <div key={i} className="timeline-item">
                    <div className="timeline-dot" />
                    <div className="timeline-content">
                      <b>{a.action}</b> <span className="by-actor">by {a.actor}</span>
                      <p>{a.note}</p>
                      <small>{a.timestamp ? new Date(a.timestamp).toLocaleString() : ''}</small>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="consumer-trust-footer">
            <span>🔒 Data secured on immutable ledger</span>
            <span>🌾 Farm-to-Fork Verified Supply Chain</span>
            <span>✅ Transparent Pricing</span>
          </div>
        </div>
      )}

      {product && (
        <ProvenanceCertificateModal
          isOpen={showCert}
          onClose={() => setShowCert(false)}
          product={product}
        />
      )}
    </div>
  );
};

export default ConsumerQRLookup;
