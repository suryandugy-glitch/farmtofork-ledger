import React from 'react';

export default function FluidMetricsBar({ items = [], onOpenAIMonitor, onOpenQRGallery }) {
  const totalLots = items.length;
  const plantLots = items.filter(p => p.category === 'plant').length;
  const animalLots = items.filter(p => p.category === 'animal').length;

  // Average farmer share calculation
  let totalShare = 0;
  let countShare = 0;
  let totalVerifications = 0;

  items.forEach(p => {
    if (p.farmerPrice && p.retailPrice) {
      totalShare += (p.farmerPrice / p.retailPrice) * 100;
      countShare++;
    }
    if (p.verifications) {
      totalVerifications += p.verifications.length;
    }
  });

  const avgFarmerShare = countShare > 0 ? (totalShare / countShare).toFixed(1) : '44.2';

  return (
    <div className="fluid-metrics-container">
      <div className="fluid-metrics-grid">
        {/* Metric 1: Verified Batches */}
        <div className="fluid-metric-card">
          <div className="metric-header">
            <span className="metric-icon-wrap bg-emerald">🌾</span>
            <div className="metric-meta">
              <span className="metric-tag">ACTIVE LEDGER</span>
              <h4>{totalLots} Verified Batches</h4>
            </div>
          </div>
          <div className="metric-body">
            <div className="metric-stat-row">
              <span className="metric-primary-val">{plantLots} Plant</span>
              <span className="metric-divider">/</span>
              <span className="metric-secondary-val">{animalLots} Animal</span>
            </div>
            <div className="metric-progress-track">
              <div
                className="metric-progress-fill"
                style={{ width: `${(plantLots / Math.max(totalLots, 1)) * 100}%` }}
              />
            </div>
            <span className="metric-footer-note">100% Geo-tagged & Lot-Certified</span>
          </div>
        </div>

        {/* Metric 2: Fair Trade Share */}
        <div className="fluid-metric-card highlight-glow">
          <div className="metric-header">
            <span className="metric-icon-wrap bg-amber">⚖️</span>
            <div className="metric-meta">
              <span className="metric-tag">FAIR PRICING INDEX</span>
              <h4>{avgFarmerShare}% Farmer Share</h4>
            </div>
          </div>
          <div className="metric-body">
            <div className="metric-stat-row">
              <span className="metric-delta positive">↑ +26.2%</span>
              <span className="metric-sublabel">vs conventional retail (18%)</span>
            </div>
            <div className="metric-spark-bar">
              <span className="spark-bar-fill" style={{ width: `${avgFarmerShare}%` }} />
            </div>
            <span className="metric-footer-note">Intermediary margin capped & transparent</span>
          </div>
        </div>

        {/* Metric 3: Consensus Proofs */}
        <div className="fluid-metric-card">
          <div className="metric-header">
            <span className="metric-icon-wrap bg-violet">⛓️</span>
            <div className="metric-meta">
              <span className="metric-tag">SHA-256 CONSENSUS</span>
              <h4>{totalVerifications} Cryptographic Proofs</h4>
            </div>
          </div>
          <div className="metric-body">
            <div className="metric-stat-row">
              <span className="metric-primary-val">0 Tamper Alerts</span>
              <span className="metric-badge-ok">Immutable</span>
            </div>
            <div className="metric-hash-preview">
              <code>0xa3f5...94c9 · 0x17d2...8b34</code>
            </div>
            <span className="metric-footer-note">Farmer → USDA → Aggregator → Retailer</span>
          </div>
        </div>

        {/* Metric 4: AI Valuation Worker */}
        <div className="fluid-metric-card ai-card" onClick={onOpenAIMonitor} title="Click to view AI Valuation Engine">
          <div className="metric-header">
            <span className="metric-icon-wrap bg-cyan">🤖</span>
            <div className="metric-meta">
              <span className="metric-tag">AI VALUATION MODEL</span>
              <h4>Autonomous Auditor</h4>
            </div>
            <span className="ai-live-badge">
              <span className="ai-dot-ping" />
              10s Cycle
            </span>
          </div>
          <div className="metric-body">
            <div className="metric-stat-row">
              <span className="metric-ai-status">Optimal Fairness</span>
              <span className="metric-launch-btn">Inspect ↗</span>
            </div>
            <div className="metric-ai-telemetry">
              <span>Hedonic Multi-Factor Engine active on 10 commodity baselines</span>
            </div>
            <span className="metric-footer-note">Zero price exploitation detected</span>
          </div>
        </div>
      </div>
    </div>
  );
}
