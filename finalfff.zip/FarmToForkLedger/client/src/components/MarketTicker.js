import React from 'react';

const TICKER_ITEMS = [
  { icon: '🍎', name: 'Organic Fuji Apples', price: '₹100/kg', delta: '+2.4%', status: 'Fair Price', hash: '0xa3f5...94c9' },
  { icon: '🥭', name: 'Ratnagiri Alphonso', price: '₹550/kg', delta: 'GI Tagged', status: 'Optimal', hash: '0xd4a8...5e01' },
  { icon: '🥛', name: 'A2 Gir Cow Milk', price: '₹52/L', delta: 'Zero Antibiotics', status: 'Fair Price', hash: '0xe5b9...6f12' },
  { icon: '🍯', name: 'Sundarbans Honey', price: '₹380/kg', delta: 'NMR Tested', status: 'Certified', hash: '0xf6c1...7a23' },
  { icon: '🍓', name: 'Organic Strawberries', price: '₹140/kg', delta: 'Cold-Chain 2°C', status: 'In-Transit', hash: '0x17d2...8b34' },
  { icon: '🧀', name: 'Nilgiri Goat Cheese', price: '₹320/kg', delta: 'Aged 60d', status: 'Fully Verified', hash: '0x28e3...9c45' },
  { icon: '🍊', name: 'Nagpur Sweet Oranges', price: '₹48/kg', delta: 'Wax-Free', status: 'Verified', hash: '0x39f4...0d56' },
  { icon: '🥚', name: 'Free-Range Eggs', price: '₹290/crate', delta: 'Pasture Fed', status: 'Optimal', hash: '0xb8d2...1f4a' },
  { icon: '🍅', name: 'Heirloom Tomatoes', price: '₹120/kg', delta: 'Non-GMO', status: 'Fair Price', hash: '0xc1e7...3b8d' },
];

export default function MarketTicker({ onSelectProduct }) {
  // Double items for seamless infinite scroll
  const stream = [...TICKER_ITEMS, ...TICKER_ITEMS];

  return (
    <div className="fluid-ticker-wrap">
      <div className="ticker-badge">
        <span className="ticker-pulse-dot" />
        <span className="ticker-label">LIVE AGRI-LEDGER</span>
      </div>

      <div className="ticker-scroll-track">
        <div className="ticker-content">
          {stream.map((item, idx) => (
            <div
              key={idx}
              className="ticker-item"
              onClick={() => onSelectProduct && onSelectProduct(item.name)}
              title={`Click to inspect ${item.name} (${item.hash})`}
            >
              <span className="ticker-icon">{item.icon}</span>
              <span className="ticker-name">{item.name}</span>
              <span className="ticker-price">{item.price}</span>
              <span className="ticker-delta">{item.delta}</span>
              <span className="ticker-status">{item.status}</span>
              <span className="ticker-sep">•</span>
            </div>
          ))}
        </div>
      </div>

      <div className="ticker-stat-pill">
        <span className="ticker-block-icon">⛓️</span>
        <span className="ticker-block-text">Block #849,219</span>
      </div>
    </div>
  );
}
