import React, { useState, useEffect, useCallback } from 'react';

import { API_URL as API } from '../config';

const CATEGORY_FILTERS = [
  { label: 'All Categories', value: '' },
  { label: '🌿 Plant-based', value: 'plant' },
  { label: '🐄 Animal', value: 'animal' },
];

const STATUS_FILTERS = [
  { label: 'Any Status', value: '' },
  { label: '📝 Draft', value: 'draft' },
  { label: '🔵 Awaiting USDA', value: 'awaiting-usda' },
  { label: '✅ USDA Approved', value: 'usda-approved' },
  { label: '🔴 Correction Required', value: 'usda-correction-required' },
  { label: '🚚 In Transit', value: 'in-transit' },
  { label: '🌟 Fully Verified', value: 'fully-verified' },
];

const ProductSearchBar = ({ onResults, allProducts }) => {
  const [query, setQuery]               = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [statusFilter, setStatusFilter]     = useState('');
  const [searching, setSearching]       = useState(false);
  const [resultCount, setResultCount]   = useState(null);

  // Apply client-side category + status filters on top of a product list
  const applyFilters = useCallback((list) => {
    let out = list;
    if (categoryFilter) out = out.filter(p => (p.category || '') === categoryFilter);
    if (statusFilter)   out = out.filter(p => (p.status   || '') === statusFilter);
    return out;
  }, [categoryFilter, statusFilter]);

  const search = useCallback(async (q) => {
    let base;
    if (!q.trim()) {
      base = allProducts;
    } else {
      setSearching(true);
      try {
        const res  = await fetch(`${API}/search?q=${encodeURIComponent(q.trim())}`);
        base = await res.json();
      } catch {
        // fall back to local filter
        const lq = q.toLowerCase();
        base = allProducts.filter(p =>
          [p.name, p.farm, p.location, p.category, p.batchId, p.qrCode, p.status,
           ...(p.certifications || []),
           ...(p.verifications || []).map(v => v.actor + ' ' + v.note),
           ...(p.auditLog || []).map(a => a.actor + ' ' + a.action + ' ' + a.note),
           p.farmerPrice != null ? String(p.farmerPrice) : '',
           p.retailPrice  != null ? String(p.retailPrice)  : '',
          ].some(v => v && String(v).toLowerCase().includes(lq))
        );
      } finally {
        setSearching(false);
      }
    }
    const filtered = applyFilters(base);
    onResults(filtered);
    setResultCount(q.trim() || categoryFilter || statusFilter ? filtered.length : null);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allProducts, onResults, applyFilters]);

  // Debounce text search
  useEffect(() => {
    const t = setTimeout(() => search(query), 300);
    return () => clearTimeout(t);
  }, [query, search]);

  // Re-apply filters whenever filter dropdowns change
  useEffect(() => {
    search(query);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoryFilter, statusFilter]);

  const clearAll = () => {
    setQuery('');
    setCategoryFilter('');
    setStatusFilter('');
    onResults(allProducts);
    setResultCount(null);
  };

  const hasFilters = query || categoryFilter || statusFilter;

  return (
    <div className="search-bar-wrap">
      {/* ── Text search row ── */}
      <div className="search-bar">
        <span className="search-icon">🔍</span>
        <input
          type="text"
          placeholder="Search by product name, farm, location, batch ID, certification, price, status…"
          value={query}
          onChange={e => setQuery(e.target.value)}
          aria-label="Search products"
        />
        {query && (
          <button className="clear-search" onClick={() => setQuery('')} title="Clear search text">×</button>
        )}
        {searching && <span className="search-spinner">⟳</span>}
      </div>

      {/* ── Filter chips row ── */}
      <div className="filter-chips-row">
        <span className="filter-label">Filters:</span>

        <div className="filter-chip-group">
          {CATEGORY_FILTERS.map(f => (
            <button
              key={f.value}
              className={`filter-chip${categoryFilter === f.value ? ' filter-chip-active' : ''}`}
              onClick={() => setCategoryFilter(prev => prev === f.value ? '' : f.value)}
            >
              {f.label}
            </button>
          ))}
        </div>

        <select
          className="filter-select"
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value)}
          aria-label="Filter by status"
        >
          {STATUS_FILTERS.map(f => (
            <option key={f.value} value={f.value}>{f.label}</option>
          ))}
        </select>

        {hasFilters && (
          <button className="filter-clear-all" onClick={clearAll} title="Clear all filters">
            ✕ Clear all
          </button>
        )}
      </div>

      {/* ── Result count ── */}
      {resultCount !== null && (
        <p className="search-results-count">
          {resultCount === 0
            ? '⚠️ No products matched your search or filters. Try a different term or remove filters.'
            : `✅ ${resultCount} product${resultCount !== 1 ? 's' : ''} found`}
        </p>
      )}
    </div>
  );
};

export default ProductSearchBar;
