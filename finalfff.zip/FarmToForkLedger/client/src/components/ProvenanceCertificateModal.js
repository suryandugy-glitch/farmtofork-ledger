import React from 'react';

export default function ProvenanceCertificateModal({ isOpen, onClose, product }) {
  if (!isOpen || !product) return null;

  const farmerSharePct = product.farmerPrice && product.retailPrice
    ? Math.round((product.farmerPrice / product.retailPrice) * 100)
    : 44;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fluid-modal-overlay" onClick={onClose}>
      <div className="certificate-modal-card" onClick={e => e.stopPropagation()}>
        {/* Actions bar above certificate */}
        <div className="cert-actions-bar">
          <span>📜 Official Ledger Provenance Document</span>
          <div className="cert-btns">
            <button type="button" className="btn-cert-print" onClick={handlePrint}>
              🖨️ Print / Save as PDF
            </button>
            <button className="fluid-modal-close" onClick={onClose}>✕</button>
          </div>
        </div>

        {/* Certificate Printable Canvas */}
        <div className="certificate-frame">
          <div className="cert-inner-border">
            {/* Certificate Header */}
            <div className="cert-header">
              <div className="cert-seal-badge">
                <span>🛡️</span>
                <b>VERIFIED LEDGER</b>
              </div>
              <span className="cert-kicker">FARMTOFORK IMMUTABLE PROVENANCE REGISTER</span>
              <h2>CERTIFICATE OF PROVENANCE &amp; FAIR PRICING</h2>
              <p className="cert-sub">
                This document certifies the authenticated agricultural origin, cold-chain integrity, and price transparency under cryptographically sealed ledger consensus.
              </p>
            </div>

            {/* Product Spotlight */}
            <div className="cert-product-spotlight">
              <span className="cert-product-emoji">{product.emoji || '🌾'}</span>
              <div className="cert-product-details">
                <h3>{product.name}</h3>
                <span className="cert-farm-meta">
                  Cultivated at <b>{product.farm}</b> • {product.location}
                </span>
                <div className="cert-batch-badges">
                  <code>Batch: {product.batchId}</code>
                  <code>QR: {product.qrCode}</code>
                  <span className="cert-cat-badge">{product.category === 'animal' ? '🐄 Animal Produce' : '🌿 Plant Produce'}</span>
                </div>
              </div>

              {/* QR Code */}
              <div className="cert-qr-wrap">
                <img
                  src={`/assets/qr-codes/${product.name.toLowerCase().includes('mango') ? 'mango_qr.png' : product.name.toLowerCase().includes('milk') ? 'milk_qr.png' : product.name.toLowerCase().includes('honey') ? 'honey_qr.png' : product.name.toLowerCase().includes('strawberr') ? 'strawberry_qr.png' : product.name.toLowerCase().includes('cheese') ? 'cheese_qr.png' : product.name.toLowerCase().includes('orange') ? 'orange_qr.png' : product.name.toLowerCase().includes('apple') ? 'apple_qr.png' : product.name.toLowerCase().includes('egg') ? 'eggs_qr.png' : 'tomato_qr.png'}`}
                  alt="Scannable QR"
                  className="cert-qr-img"
                />
                <small>Scan to Verify</small>
              </div>
            </div>

            {/* Price Architecture Box */}
            <div className="cert-price-box">
              <div className="cert-price-col">
                <span className="cpc-label">AUTHENTIC FARMGATE PRICE</span>
                <b className="cpc-val farmer-val">₹{product.farmerPrice}</b>
                <small>Paid directly to farmer</small>
              </div>
              <div className="cert-price-col">
                <span className="cpc-label">CONSUMER RETAIL PRICE</span>
                <b className="cpc-val retail-val">₹{product.retailPrice}</b>
                <small>Shelf price verified</small>
              </div>
              <div className="cert-price-col">
                <span className="cpc-label">PRODUCER SHARE RATIO</span>
                <b className="cpc-val share-val">{farmerSharePct}%</b>
                <small>+26% vs conventional avg</small>
              </div>
              <div className="cert-price-col">
                <span className="cpc-label">AI FAIRNESS VERDICT</span>
                <b className="cpc-val ai-val">96/100</b>
                <small>Zero Middleman Gouging</small>
              </div>
            </div>

            {/* Multi-Signature Verification Trail */}
            <div className="cert-signatures-row">
              <div className="cert-sig-block">
                <span className="sig-label">PRODUCER NOTARY</span>
                <div className="sig-line">✓ {product.farm}</div>
                <small>Origin &amp; Harvest Lot Authenticated</small>
              </div>
              <div className="cert-sig-block">
                <span className="sig-label">FOOD SAFETY DESK</span>
                <div className="sig-line">✓ USDA Standards Desk</div>
                <small>Chemical &amp; Organic Standard Met</small>
              </div>
              <div className="cert-sig-block">
                <span className="sig-label">LOGISTICS &amp; COLD-CHAIN</span>
                <div className="sig-line">✓ AgriHub Express</div>
                <small>Cold Integrity Maintained</small>
              </div>
              <div className="cert-sig-block">
                <span className="sig-label">BLOCKCHAIN ROOT</span>
                <div className="sig-line-hash"><code>{product.blockchainHash || '0xa3f5c7d8e2b1f94c9c2e'}</code></div>
                <small>Sealed on Ledger Block #849,219</small>
              </div>
            </div>

            {/* Certificate Footer */}
            <div className="cert-footer">
              <span>🌾 Powered by FarmToFork Distributed Ledger Technology</span>
              <span>🔒 Cryptographically Signed • Non-Repudiable • Publicly Auditable</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
