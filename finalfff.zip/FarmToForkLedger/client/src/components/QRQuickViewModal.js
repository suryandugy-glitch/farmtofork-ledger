import React, { useState } from 'react';

const QR_DEMO_ITEMS = [
  { id: '1', name: 'Organic Fuji Apples', emoji: '🍎', category: 'plant', code: 'FTF-001-APPLE-20260919', file: 'apple_qr.png', farm: 'Shimla, Himachal Pradesh', price: '₹100 (Retail ₹250)' },
  { id: '2', name: 'Free-range Chicken Eggs', emoji: '🥚', category: 'animal', code: 'FTF-002-EGGS-20260919', file: 'eggs_qr.png', farm: 'Pune, Maharashtra', price: '₹290 (Retail ₹500)' },
  { id: '3', name: 'Heirloom Tomato Mix', emoji: '🍅', category: 'plant', code: 'FTF-003-TOMATO-20260919', file: 'tomato_qr.png', farm: 'Nashik, Maharashtra', price: '₹120 (Retail ₹250)' },
  { id: '4', name: 'Ratnagiri Alphonso Mangoes', emoji: '🥭', category: 'plant', code: 'FTF-004-MANGO-20260920', file: 'mango_qr.png', farm: 'Ratnagiri, Maharashtra', price: '₹550 (Retail ₹1150)' },
  { id: '5', name: 'A2 Gir Cow Fresh Milk', emoji: '🥛', category: 'animal', code: 'FTF-005-MILK-20260920', file: 'milk_qr.png', farm: 'Karnal, Haryana', price: '₹52 (Retail ₹90)' },
  { id: '6', name: 'Sundarbans Wild Raw Honey', emoji: '🍯', category: 'animal', code: 'FTF-006-HONEY-20260920', file: 'honey_qr.png', farm: 'South 24 Parganas, WB', price: '₹380 (Retail ₹650)' },
  { id: '7', name: 'Mahabaleshwar Strawberries', emoji: '🍓', category: 'plant', code: 'FTF-007-STRAWBERRY-20260920', file: 'strawberry_qr.png', farm: 'Mahabaleshwar, Maharashtra', price: '₹140 (Retail ₹280)' },
  { id: '8', name: 'Artisanal Nilgiri Goat Cheese', emoji: '🧀', category: 'animal', code: 'FTF-008-CHEESE-20260920', file: 'cheese_qr.png', farm: 'Ooty, Tamil Nadu', price: '₹320 (Retail ₹550)' },
  { id: '9', name: 'Nagpur Organic Sweet Oranges', emoji: '🍊', category: 'plant', code: 'FTF-009-ORANGE-20260920', file: 'orange_qr.png', farm: 'Nagpur, Maharashtra', price: '₹48 (Retail ₹105)' },
];

export default function QRQuickViewModal({ isOpen, onClose, onSelectQRForConsumer }) {
  const [filter, setFilter] = useState('all');
  const [copiedCode, setCopiedCode] = useState('');

  if (!isOpen) return null;

  const filtered = QR_DEMO_ITEMS.filter(item => {
    if (filter === 'all') return true;
    return item.category === filter;
  });

  const copyToClipboard = (code) => {
    navigator.clipboard?.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(''), 2000);
  };

  return (
    <div className="fluid-modal-overlay" onClick={onClose}>
      <div className="fluid-modal-card" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="fluid-modal-header">
          <div className="fluid-modal-title-group">
            <span className="modal-kicker">INTERACTIVE DEMO ASSETS</span>
            <h3>⚡ Product QR Code Gallery &amp; Scanner Demo</h3>
            <p>
              Scannable QR codes for all 9 plant &amp; animal commodities. Test by scanning with phone camera, uploading PNG to consumer portal, or clicking test below.
            </p>
          </div>
          <button className="fluid-modal-close" onClick={onClose}>✕</button>
        </div>

        {/* Filter Pills */}
        <div className="qr-filter-ribbon">
          {[
            { key: 'all', label: 'All Products (9)' },
            { key: 'plant', label: '🌿 Plant & Fruits (5)' },
            { key: 'animal', label: '🐄 Dairy & Animal (4)' },
          ].map(tab => (
            <button
              key={tab.key}
              className={`qr-filter-tab ${filter === tab.key ? 'active' : ''}`}
              onClick={() => setFilter(tab.key)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Grid of QR cards */}
        <div className="qr-modal-grid">
          {filtered.map(item => (
            <div key={item.id} className="qr-card-item">
              <div className="qr-card-header">
                <span className="qr-item-emoji">{item.emoji}</span>
                <div className="qr-item-info">
                  <b>{item.name}</b>
                  <small>{item.farm}</small>
                </div>
              </div>

              {/* Scannable image */}
              <div className="qr-img-wrapper">
                <img
                  src={`/assets/qr-codes/${item.file}`}
                  alt={`QR Code for ${item.name}`}
                  className="qr-card-img"
                />
                <span className="qr-scan-badge">Ready to Scan</span>
              </div>

              <div className="qr-payload-box">
                <code>{item.code}</code>
                <button
                  type="button"
                  className="qr-copy-btn"
                  onClick={() => copyToClipboard(item.code)}
                  title="Copy QR string"
                >
                  {copiedCode === item.code ? '✓ Copied' : '📋 Copy'}
                </button>
              </div>

              <div className="qr-card-meta">
                <span>Fair Price: <b>{item.price}</b></span>
              </div>

              <div className="qr-card-actions">
                <a
                  href={`/assets/qr-codes/${item.file}`}
                  download={item.file}
                  className="qr-btn-download"
                  title="Download PNG QR image"
                >
                  📥 Download PNG
                </a>
                {onSelectQRForConsumer && (
                  <button
                    type="button"
                    className="qr-btn-test"
                    onClick={() => {
                      onSelectQRForConsumer(item.code);
                      onClose();
                    }}
                    title="Open in Consumer Transparency Portal"
                  >
                    🔍 Test in Consumer View →
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="fluid-modal-footer">
          <small>
            💡 Tip: Saved in <code>C:\Users\HP\Downloads\WORK1\qr-codes\</code>. Drag or upload any PNG into the Consumer Transparency Portal.
          </small>
          <button className="primary-sm" onClick={onClose}>Done</button>
        </div>
      </div>
    </div>
  );
}
