require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const path    = require('path');
const multer  = require('multer');

const app  = express();
const PORT = process.env.PORT || 5001;

// ── Memory storage for uploads (100% compatible with Vercel Serverless & Local) ──
const storage = multer.memoryStorage();
const upload  = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB limit
  fileFilter: (req, file, cb) => {
    if (file.mimetype && file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed.'));
    }
  },
});

// ── Middleware ──
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Image upload endpoint ──
// POST /api/upload (field: "image")
app.post('/api/upload', upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No image file received.' });
  }

  // Convert uploaded image buffer to Base64 Data URL for universal compatibility
  const base64Data = req.file.buffer.toString('base64');
  const mimeType   = req.file.mimetype || 'image/jpeg';
  const imageUrl   = `data:${mimeType};base64,${base64Data}`;

  res.json({
    message:  'Image uploaded successfully.',
    imageUrl,
    filename: req.file.originalname,
    size:     req.file.size,
  });
});

// Handle multer errors
app.use((err, req, res, next) => {
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ message: 'File too large. Maximum size is 5 MB.' });
  }
  if (err.message) {
    return res.status(400).json({ message: err.message });
  }
  next(err);
});

// ── API Routes ──
const productRoutes = require('./routes/products');
const aiRoutes = require('./routes/aiRoutes');
app.use('/api/products', productRoutes);
app.use('/api/ai', aiRoutes);

// ── Start Autonomous AI Background Audit Worker ──
const aiWorker = require('./services/aiBackgroundWorker');
aiWorker.start(10000); // 10s continuous background audit cycle

// ── Health check ──
app.get('/api/health', (req, res) => {
  res.json({ message: 'FarmToFork Ledger API is running!', status: 'OK' });
});

// ── Serve React build in local production mode ──
if (process.env.NODE_ENV === 'production' && !process.env.VERCEL) {
  app.use(express.static(path.join(__dirname, '..', 'client', 'build')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'client', 'build', 'index.html'));
  });
}

// ── Start server only when run directly (not when imported as Vercel serverless function) ──
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

module.exports = app;
